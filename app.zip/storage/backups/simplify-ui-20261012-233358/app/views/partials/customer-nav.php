<?php if (($_SESSION['user']['role'] ?? '') === 'pelanggan'):
  $customerPath = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?? '';
  $customerLinks = [['/produk', 'product', 'Belanja'], ['/keranjang', 'cart', 'Keranjang'], ['/transaksi', 'orders', 'Pesanan Saya'], ['/profil', 'users', 'Profil Saya']];
?>
<nav class="sf-account-nav" aria-label="Navigasi pelanggan">
  <?php foreach ($customerLinks as [$customerHref, $customerIcon, $customerLabel]):
    $customerActive = str_ends_with(rtrim($customerPath, '/'), $customerHref) || ($customerHref === '/transaksi' && str_contains($customerPath, '/pembayaran/'));
  ?>
    <a href="<?= BASE_URL . $customerHref ?>" class="<?= $customerActive ? 'is-active' : '' ?>" <?= $customerActive ? 'aria-current="page"' : '' ?>><?= masterIconSvg($customerIcon, 'h-4 w-4') ?><span><?= $customerLabel ?></span></a>
  <?php endforeach; ?>
</nav>
<?php endif; ?>

<section class="auth-brand-panel">
  <img src="<?= BASE_URL ?>/assets/logo.png" alt="Logo GGmart" class="auth-logo">
  <div class="mt-8">
    <p class="mb-4 text-xs font-semibold uppercase tracking-widest text-green-200">Toko Pangan Sinode GMIT</p>
    <p class="auth-brand-title">Belanja lokal.<br>Tumbuh bersama.</p>
    <p class="auth-brand-text">Temukan produk jemaat dan UMKM Nusa Tenggara Timur. Simpan pilihan Anda dan pantau pesanan dalam satu akun.</p>
    <img src="<?= BASE_URL ?>/assets/banner-ggmart.png" alt="Toko GGmart di Kupang" width="592" height="357" class="sf-auth-photo">
  </div>
</section>

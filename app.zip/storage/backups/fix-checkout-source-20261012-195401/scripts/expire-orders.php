<?php
require __DIR__ . '/bootstrap.php';
expireOrders();
if (midtransKey()==='') { echo "Pesanan lokal diperiksa. QRIS belum dikonfigurasi.\n"; exit; }
$rows=oq("SELECT kode_transaksi,midtrans_order_id,midtrans_env FROM transaksi WHERE status='pending' AND status_bayar='belum_bayar' AND midtrans_order_id IS NOT NULL AND batas_bayar<NOW() LIMIT 30")->fetch_all(MYSQLI_ASSOC);
foreach ($rows as $row) {
  try {
    if ($row['midtrans_env']!==midtransEnvironment()) continue;
    $path=rawurlencode($row['midtrans_order_id']); $payload=midtransRequest($path . '/status');
    if ((string)($payload['status_code'] ?? '')==='404') continue;
    if (($payload['transaction_status'] ?? '')==='pending') {
      // Cancel mengakhiri QRIS pending yang sudah melewati batas lokal.
      midtransRequest($path . '/cancel','POST');
      $payload=midtransRequest($path . '/status');
    }
    syncMidtrans($payload);
    echo $row['kode_transaksi'] . ": diperiksa.\n";
  } catch (Throwable $e) { echo $row['kode_transaksi'] . ": pemeriksaan ditunda; gateway belum dapat dikonfirmasi.\n"; }
}

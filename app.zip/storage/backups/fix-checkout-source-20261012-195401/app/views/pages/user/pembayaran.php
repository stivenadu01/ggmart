<div class="user-container space-y-5 py-8">
  <div><h1 class="user-section-title">Pembayaran Pesanan</h1><p class="user-section-subtitle">Selesaikan pembayaran dan lihat informasi pengambilan barang.</p></div>
  <?php include ROOT_PATH . '/app/views/partials/payment.php'; ?>
  <a href="<?= BASE_URL . (($_SESSION['user']['role'] ?? '') === 'pelanggan' ? '/transaksi' : '/admin/kasir') ?>" class="user-action-outline">Kembali</a>
</div>

<section class="card space-y-5 p-4 sm:p-6" x-data="storeSettingsPage()">
  <div><h2 class="text-lg font-semibold">Pembayaran dan Pengiriman</h2><p class="form-help">Atur rekening transfer serta tarif pengantaran per kelurahan.</p></div>
  <p x-show="!loaded" class="text-sm text-slate-500">Pengaturan belum dimuat. Muat ulang halaman jika diperlukan.</p>
  <div x-show="loaded" class="space-y-5">
    <div class="grid gap-4 sm:grid-cols-3">
      <label class="label">Nama bank<input class="input mt-2 w-full" x-model.trim="rekening.bank_nama" maxlength="120" placeholder="Nama bank"></label>
      <label class="label">Nomor rekening<input class="input mt-2 w-full" x-model.trim="rekening.bank_rekening" maxlength="40" inputmode="numeric" placeholder="Nomor rekening toko"></label>
      <label class="label">Pemilik rekening<input class="input mt-2 w-full" x-model.trim="rekening.bank_pemilik" maxlength="120" placeholder="Nama sesuai rekening"></label>
    </div>
    <div class="rounded-xl bg-slate-50 p-4 text-sm"><p class="font-semibold" x-text="qris ? 'QRIS tersedia — ' + environment : 'QRIS belum dikonfigurasi'"></p><p class="mt-1">Server Key dibaca dari MIDTRANS_SERVER_KEY pada .env. Mode mengikuti MIDTRANS_IS_PRODUCTION.</p><p class="mt-2">URL notifikasi Midtrans: <span class="break-all font-mono" x-text="notification"></span></p><p class="mt-1 text-slate-500">Untuk pengujian localhost, gunakan URL publik dari tunnel pada dashboard Midtrans.</p></div>
    <div><h3 class="font-semibold">Tarif per kelurahan</h3><p class="form-help">Ambil di tempat selalu Rp0. Nonaktifkan wilayah yang belum dilayani. Perubahan tarif hanya berlaku untuk pesanan baru.</p><input type="search" class="input mt-3 w-full" x-model="filter" placeholder="Cari kelurahan..."></div>
    <div class="max-h-96 overflow-auto rounded-xl border border-slate-200"><table class="table"><thead><tr><th>Kelurahan</th><th>Ongkir (Rp)</th><th>Dilayani</th></tr></thead><tbody><template x-for="z in filtered" :key="z.id"><tr><td x-text="z.kelurahan"></td><td><input type="number" min="0" max="1000000" step="1000" class="input w-32" x-model.number="z.tarif" :aria-label="'Tarif ' + z.kelurahan"></td><td><input type="checkbox" x-model="z.aktif" :aria-label="'Layani ' + z.kelurahan"></td></tr></template></tbody></table></div>
    <button class="admin-action-primary" @click="save()" :disabled="busy"><span x-text="busy ? 'Menyimpan...' : 'Simpan pengaturan toko'"></span></button>
  </div>
</section>

<?php
class ApiPengaturanController
{
  public function checkout()
  {
    try {
      expireOrders();
      response(['success'=>true,'data'=>['zona'=>oq('SELECT id,kelurahan,tarif FROM zona_pengiriman WHERE aktif=1 ORDER BY kelurahan')->fetch_all(MYSQLI_ASSOC),'rekening'=>storeSettings(),'metode'=>paymentMethods(),'alamat_toko'=>'Jl. S. K. Lerik, Kota Baru, Kecamatan Kelapa Lima, Kota Kupang','midtrans_env'=>midtransEnvironment()]]);
    } catch (Throwable $e) { orderError($e); }
  }
  public function detail()
  {
    try { response(['success'=>true,'data'=>['rekening'=>storeSettings(),'zona'=>oq('SELECT * FROM zona_pengiriman ORDER BY kelurahan')->fetch_all(MYSQLI_ASSOC),'qris_tersedia'=>midtransKey()!=='','midtrans_env'=>midtransEnvironment(),'notification_url'=>BASE_URL . '/api/pembayaran/notifikasi']]); }
    catch (Throwable $e) { orderError($e); }
  }
  public function simpan()
  {
    db()->begin_transaction();
    try {
      $input=input();
      $settings=[];
      foreach (['bank_nama','bank_rekening','bank_pemilik'] as $name) {
        $value=trim((string)($input['rekening'][$name] ?? ''));
        if (mb_strlen($value)>120) throw new Exception('Informasi rekening terlalu panjang.',422);
        if ($name==='bank_rekening' && $value!=='' && !preg_match('/^[0-9 -]{5,40}$/',$value)) throw new Exception('Nomor rekening tidak valid.',422);
        $settings[$name]=$value;
      }
      if (count(array_filter($settings,fn($v)=>$v!==''))!==0 && count(array_filter($settings,fn($v)=>$v!==''))!==3) throw new Exception('Nama bank, nomor rekening, dan pemilik harus diisi lengkap.',422);
      if (!is_array($input['zona'] ?? null) || count($input['zona'])!==51) throw new Exception('Daftar kelurahan tidak lengkap.',422);
      $seen=[];
      foreach ($input['zona'] as $zone) {
        $id=filter_var($zone['id'] ?? null,FILTER_VALIDATE_INT); $tarif=filter_var($zone['tarif'] ?? null,FILTER_VALIDATE_INT);
        if (!$id || isset($seen[$id]) || $tarif===false || $tarif<0 || $tarif>1000000 || !oq('SELECT id FROM zona_pengiriman WHERE id=?',[$id])->fetch_assoc()) throw new Exception('Tarif pengiriman tidak valid.',422);
        $seen[$id]=true;
        oq('UPDATE zona_pengiriman SET tarif=?,aktif=? WHERE id=?',[$tarif,!empty($zone['aktif']) ? 1 : 0,$id]);
      }
      foreach ($settings as $name=>$value) oq('INSERT INTO pengaturan(nama,nilai) VALUES (?,?) ON DUPLICATE KEY UPDATE nilai=VALUES(nilai)',[$name,$value]);
      db()->commit(); response(['success'=>true,'message'=>'Rekening dan tarif pengiriman disimpan.']);
    } catch (Throwable $e) { db()->rollback(); orderError($e); }
  }
}

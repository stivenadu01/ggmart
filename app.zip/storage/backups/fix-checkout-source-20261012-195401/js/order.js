function checkoutPage() {
  return {
    config: null,
    form: { metode_bayar: 'transfer', metode_pengiriman: 'ambil', zona_id: '', nama_penerima: '', no_hp_penerima: '', alamat_pengiriman: '' },
    async init() {
      const user = Alpine.store('auth').user || {};
      this.form.nama_penerima = user.nama || '';
      this.form.no_hp_penerima = user.no_hp || '';
      this.form.alamat_pengiriman = user.alamat || '';
      try {
        this.config = (await API.get('/checkout/config')).data;
        if (!this.config.metode.transfer && this.config.metode.qris) this.form.metode_bayar = 'qris';
      } catch (e) { this.config = null; }
    },
    get zone() { return this.config?.zona.find(z => String(z.id) === String(this.form.zona_id)); },
    get ongkir() { return this.form.metode_pengiriman === 'kirim' ? Number(this.zone?.tarif || 0) : 0; },
    get total() { return Alpine.store('cart').totalHarga + this.ongkir; },
    get ready() { return !!this.config?.metode[this.form.metode_bayar] && this.form.nama_penerima.trim().length >= 2 && !!this.form.no_hp_penerima.trim() && (this.form.metode_pengiriman === 'ambil' || (!!this.zone && this.form.alamat_pengiriman.trim().length >= 10)); },
    async checkout() { if (this.ready) await Alpine.store('cart').checkout(this.form); }
  };
}

function paymentPanel() {
  return {
    code: window.location.pathname.split('/').filter(Boolean).pop(), trx: null, loading: true, busy: false, error: '', note: '', proof: null,
    get role() { return Alpine.store('auth').user?.role; },
    get isAdmin() { return this.role === 'admin'; },
    get canPay() { return !!this.trx && this.trx.status === 'pending' && ['belum_bayar', 'ditolak'].includes(this.trx.status_bayar); },
    paymentLabel(status) { return ({ belum_bayar: 'Belum dibayar', menunggu_verifikasi: 'Menunggu verifikasi', lunas: 'Lunas', ditolak: 'Bukti ditolak', kedaluwarsa: 'Kedaluwarsa', perlu_refund: 'Menunggu pengembalian dana', dikembalikan: 'Dana dikembalikan' })[status] || status; },
    async init() { await this.load(); },
    async load() {
      this.loading = true; this.error = '';
      try { this.trx = (await API.get('/transaksi/detail?k=' + encodeURIComponent(this.code), false)).data; this.$dispatch('payment-updated', this.trx); }
      catch (e) { this.error = e.message; }
      finally { this.loading = false; }
    },
    async action(endpoint, extra = {}) {
      if (this.busy) return;
      this.busy = true;
      try { await API.post(endpoint, { kode_transaksi: this.code, ...extra }); await this.load(); }
      catch (e) { this.error = e.message; }
      finally { this.busy = false; }
    },
    async upload() {
      if (!this.proof || this.busy) return;
      this.busy = true;
      const data = new FormData(); data.append('kode_transaksi', this.code); data.append('bukti', this.proof);
      try { await API.post('/pembayaran/bukti', data); this.proof = null; await this.load(); }
      catch (e) { this.error = e.message; }
      finally { this.busy = false; }
    },
    async verify(action) {
      if (action === 'tolak' && this.note.trim().length < 5) { Alpine.store('ui').toast('Isi alasan penolakan minimal 5 karakter.', 'error'); return; }
      if (await Alpine.store('ui').confirm(action === 'terima' ? 'Pastikan uang telah masuk ke rekening toko. Terima pembayaran ini?' : 'Tolak bukti transfer ini?')) await this.action('/pembayaran/verifikasi', { aksi: action, catatan: this.note });
    },
    async finishCounter() {
      if (this.busy || !await Alpine.store('ui').confirm('Pastikan barang sudah diterima pembeli. Selesaikan penjualan ini?')) return;
      this.busy = true;
      try {
        if (this.trx.status === 'pending') await API.post('/transaksi/proses', { kode_transaksi: this.code });
        await API.post('/transaksi/konfirmasi', { kode_transaksi: this.code });
        await this.load();
      } catch (e) { this.error = e.message; await this.load(); }
      finally { this.busy = false; }
    },
    async refund() {
      if (this.note.trim().length < 5) { Alpine.store('ui').toast('Isi catatan pengembalian dana.', 'error'); return; }
      if (await Alpine.store('ui').confirm('Pastikan dana sudah dikembalikan kepada pelanggan. Catat pengembalian ini?')) await this.action('/pembayaran/refund', { catatan: this.note });
    },
    waLink() {
      let phone = String(this.trx?.no_hp_penerima || this.trx?.user_phone || '').replace(/\D/g, '');
      if (phone.startsWith('0')) phone = '62' + phone.slice(1);
      if (!/^628\d{7,12}$/.test(phone)) return null;
      return 'https://wa.me/' + phone + '?text=' + encodeURIComponent('Halo ' + (this.trx.nama_penerima || this.trx.user || '') + ', kami dari GGmart ingin menghubungi Anda tentang pesanan ' + this.code + '.');
    }
  };
}

function storeSettingsPage() {
  return {
    rekening: { bank_nama: '', bank_rekening: '', bank_pemilik: '' }, zona: [], filter: '', busy: false, loaded: false, qris: false, environment: 'sandbox', notification: '',
    get filtered() { return this.zona.filter(z => z.kelurahan.toLowerCase().includes(this.filter.toLowerCase())); },
    async init() {
      try {
        const d = (await API.get('/pengaturan/toko')).data;
        this.rekening = d.rekening; this.zona = d.zona.map(z => ({ ...z, aktif: Number(z.aktif) === 1 })); this.qris = d.qris_tersedia; this.environment = d.midtrans_env; this.notification = d.notification_url; this.loaded = true;
      } catch (e) { this.loaded = false; }
    },
    async save() {
      this.busy = true;
      try { await API.put('/pengaturan/toko', { rekening: this.rekening, zona: this.zona }); }
      finally { this.busy = false; }
    }
  };
}

utils.customerWhatsApp = function (trx) {
  let phone = String(trx.no_hp_penerima || trx.user_phone || '').replace(/\D/g, '');
  if (phone.startsWith('0')) phone = '62' + phone.slice(1);
  if (!/^628\d{7,12}$/.test(phone)) return null;
  return 'https://wa.me/' + phone + '?text=' + encodeURIComponent('Halo ' + (trx.nama_penerima || trx.user || '') + ', kami dari GGmart ingin menghubungi Anda tentang pesanan ' + trx.kode_transaksi + '.');
};

// getRandomValues tersedia juga ketika laptop membuka toko melalui HTTP jaringan lokal.
utils.checkoutKey = function () {
  if (globalThis.crypto.randomUUID) return globalThis.crypto.randomUUID();
  return Array.from(globalThis.crypto.getRandomValues(new Uint8Array(16)), n => n.toString(16).padStart(2, '0')).join('');
};

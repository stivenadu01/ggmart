# GGmart

PHP 8.2 atau lebih baru, MySQL/MariaDB, dan ekstensi `gd`, `zip`, `mysqli`, `curl`, `fileinfo`, `mbstring`, serta XML diperlukan. Gunakan PHP yang sama dengan Apache ketika menjalankan Composer.

## Pembayaran dan pengiriman

Pengaturan admin terdiri dari tab **Akun**, **Pembayaran**, dan **Pengiriman**. Rekening dan tarif disimpan terpisah. Tarif berupa rupiah bulat; format desimal dari database tetap diterima jika pecahannya nol. Pelanggan memeriksa keranjang dahulu, lalu menekan **Pesan Sekarang** untuk memilih pembayaran dan pengiriman. Untuk pengiriman lokal, pilih kecamatan sebelum kelurahan. Ongkir dan data penerima disimpan pada pesanan; perubahan tarif tidak mengubah pesanan lama.

Wilayah dan tarif operasional dibaca dari tabel `zona_pengiriman`. `scripts/data/tarif-awal.php` hanya mengisi tarif awal saat migrasi, sedangkan `scripts/data/kecamatan.php` mengisi pemetaan kecamatan. Pemetaan mengacu pada [Dukcapil Kota Kupang Semester I 2025](https://dukcapil.kupangkota.go.id/wp-content/uploads/dlm_uploads/2025/09/Data-Agregat-Kependudukan-Semester-I-Tahun-2025.pdf) dan BPS Kota Kupang.

Isi `.env` dengan Server Key akun Midtrans:

```dotenv
MIDTRANS_SERVER_KEY=isi_server_key_anda
MIDTRANS_IS_PRODUCTION=false
PAYMENT_EXPIRY_MINUTES=120
```

Jangan memasukkan Server Key ke JavaScript, Git, atau formulir pelanggan. Untuk Sandbox, simulasikan pembayaran melalui simulator resmi Midtrans. Atur Payment Notification URL pada dashboard Midtrans ke `https://alamat-publik/ggmart/api/pembayaran/notifikasi` (sesuaikan prefix jika tunnel menunjuk langsung ke GGmart). Notifikasi masuk ke localhost membutuhkan tunnel atau hosting yang dapat diakses internet. Halaman QRIS membuat kode otomatis dan memeriksa Get Status setiap 5 detik; pemeriksaan tetap bekerja tanpa webhook masuk. Jika jaringan gagal, pemeriksaan dicoba kembali setelah 15 detik. Integrasi menggunakan Core API QRIS: https://docs.midtrans.com/reference/qris dan https://docs.midtrans.com/docs/https-notification-webhooks.

Transfer manual diperiksa admin berdasarkan bukti dan uang yang masuk ke rekening. Status lunas dipisahkan dari status pesanan. Barang dianggap selesai setelah diterima pelanggan. Pembatalan transaksi lunas memerlukan pengembalian dana melalui kanal asal, lalu dicatat admin; aplikasi tidak otomatis mengirim refund.

Tab pelanggan: **Menunggu Pembayaran → Diproses → Dikirim → Selesai**, serta **Dibatalkan**. Bukti transfer yang belum diperiksa tetap di Menunggu Pembayaran; pesanan lunas yang belum disiapkan masuk Diproses dengan keterangan Menunggu diproses. Admin menandai pesanan pengiriman sebagai Dikirim sebelum Selesai. Pesanan ambil di tempat ditandai Siap diambil dalam tab Diproses sebelum Selesai. Pesanan yang dibatalkan hanya tampil di riwayat admin. Halaman Pesanan hanya memuat transaksi online.

Transaksi kasir memiliki asal transaksi tersendiri. QRIS kasir yang dikonfirmasi lunas oleh gateway otomatis menyelesaikan penjualan serta pencatatan FIFO sekali saja. Halaman pembayaran kembali ke kasir setelah status Selesai diterima dari server. QRIS pesanan online tidak otomatis menyelesaikan pesanan. Tidak ada tombol Hubungi Pelanggan dalam pembayaran kasir. Mode Sandbox tetap mengikuti `.env`; pembayaran Sandbox menggunakan simulator dan tidak dapat dibayar dengan aplikasi bank biasa.

Stok dicadangkan saat checkout. Pesanan transfer belum dibayar dan QRIS yang belum dibuat kedaluwarsa sesuai batas pembayaran dan cadangannya dilepas saat aplikasi diakses. QRIS yang sudah dibuat menunggu konfirmasi gateway melalui webhook atau tombol pemeriksaan agar pembayaran berhasil yang terlambat diberitahukan tidak dibatalkan keliru. Untuk rekonsiliasi berkala di hosting/Windows Task Scheduler, jalankan `D:\xampp\php\php.exe D:\xampp\htdocs\ggmart\scripts\expire-orders.php` setiap menit. Bukti yang menunggu pemeriksaan tetap mencadangkan stok sampai admin memutuskan. Penjualan memakai FIFO dan mencatat mutasi keluar saat pesanan selesai. Stok produk menampilkan jumlah yang dapat dipesan (stok fisik dikurangi reservasi).

## Instalasi dan pembaruan

```powershell
D:\xampp\php\php.exe C:\ProgramData\ComposerSetup\bin\composer.phar install
D:\xampp\php\php.exe scripts/migrate.php
npm run build
```

Migrasi membuat backup database di `storage/backups`. Untuk database baru, impor `data.sql`, atur `.env`, lalu jalankan migrasi. Script `scripts/seed-transactions.php` mengisi 10 transaksi dan 10 mutasi tanpa menambah pengguna. Script tidak menambahkan data lagi bila `storage/seed-receipt.json` sudah tersedia. Data contoh menggunakan database aktif sesuai kebutuhan presentasi; jangan menjalankan seed pada database produksi yang memiliki transaksi nyata.

Untuk memperbarui instalasi yang sudah memiliki tabel pembayaran/pengiriman, jalankan `D:\xampp\php\php.exe scripts/upgrade-checkout.php`. Script membuat backup, menambahkan kecamatan dan asal transaksi, serta memperluas status pengiriman tanpa mengubah tarif atau menambah data contoh. Pembaruan ini sudah dijalankan pada workspace ini.

Pimpinan hanya memantau data dan mengekspor laporan. Endpoint ekspor ditolak untuk admin. Pengelolaan produk, kategori, stok, pembayaran, dan tarif dilakukan admin. Laporan penjualan dan laba kotor menggunakan subtotal barang; penerimaan ongkir ditampilkan terpisah.

## Pemeriksaan

```powershell
D:\xampp\php\php.exe tests/order-integration.php
D:\xampp\php\php.exe tests/http-integration.php
D:\xampp\php\php.exe tests/payment-integration.php
D:\xampp\php\php.exe tests/settings-integration.php
D:\xampp\php\php.exe tests/checkout-regression.php
node tests/checkout-ui.js
```

Pengujian memulihkan rekening dan tarif setelah pemeriksaan; data transaksi dan produk sementara dibersihkan tanpa menambah akun. Pemeriksaan FIFO menggunakan rollback. `checkout-regression.php` menguji respons gateway di batas service (termasuk settlement berulang dan expiry), sedangkan `checkout-ui.js` menguji otomatisasi tampilan/redirect menggunakan respons API simulasi. Pengujian tersebut tidak menggantikan pengujian pembayaran dengan simulator Sandbox.

Dengan Server Key Sandbox di `.env`, `D:\xampp\php\php.exe tests/midtrans-integration.php` menguji pembuatan QRIS, gambar, Get Status, dan pembatalan gateway. Pembayaran berhasil diuji melalui [simulator Midtrans](https://simulator.sandbox.midtrans.com/v2/qris/index); simulator dapat mengembalikan galat layanan. Pengujian lokal sementara dibersihkan setelah selesai.

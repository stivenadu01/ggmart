const fs = require('fs');
const vm = require('vm');
const assert = require('assert/strict');
const source = fs.readFileSync('public/assets/js/order.js', 'utf8');
let role = 'admin', scheduled, location, stage, calls;
const stores = { auth: { get user() { return { role }; } }, cart: { items: [{ jumlah: 1 }], totalHarga: 1000, async checkout() {} } };
const fixture = () => ({ kode_transaksi: 'GT-test', sumber_transaksi: 'kasir', metode_bayar: 'qris', status: stage === 'paid' ? 'selesai' : stage === 'expired' ? 'dibatalkan' : 'pending', status_bayar: stage === 'paid' ? 'lunas' : stage === 'expired' ? 'kedaluwarsa' : 'belum_bayar', qris_url: stage !== 'initial' ? 'https://api.sandbox.midtrans.com/qr' : null, midtrans_order_id: stage !== 'initial' ? 'GT-test' : null });
const context = vm.createContext({ utils: {}, BASE_URL: '/ggmart', Alpine: { store: name => stores[name] }, document: { hidden: false }, window: { location: { pathname: '/ggmart/pembayaran/GT-test', replace: value => { location = value; } }, scrollTo() {} }, globalThis: { crypto: { randomUUID() { return 'test'; } } }, setTimeout: fn => { scheduled = fn; return 1; }, clearTimeout: () => { scheduled = null; }, API: {
  async get() { return { data: fixture() }; },
  async post(endpoint) { calls.push(endpoint); if (endpoint === '/pembayaran/qris') stage = 'qr'; else if (endpoint === '/pembayaran/status') stage = 'paid'; }
} });
vm.runInContext(source, context);
async function run() {
  const checkout = context.checkoutPage(); checkout.config = { zona: [{ id: 1, kecamatan: 'Oebobo', kelurahan: 'Fatululi', tarif: '5000.00' }, { id: 2, kecamatan: 'Alak', kelurahan: 'Alak', tarif: '30000.00' }] };
  assert.equal(checkout.step, 1); checkout.next(); assert.equal(checkout.step, 2);
  checkout.form.metode_pengiriman = 'kirim'; checkout.form.kecamatan = 'Oebobo'; checkout.form.zona_id = 1;
  assert.equal(checkout.kelurahan.length, 1); assert.equal(checkout.ongkir, 5000); assert.equal(checkout.total, 6000);
  checkout.form.kecamatan = 'Alak'; checkout.changeDistrict(); assert.equal(checkout.form.zona_id, ''); assert.equal(checkout.ongkir, 0);
  console.log('PASS: Two-step checkout and kecamatan-dependent shipping total');
  stage = 'initial'; calls = []; location = undefined;
  const panel = context.paymentPanel(); panel.$dispatch = () => {};
  await panel.init(); assert.equal(calls[0], '/pembayaran/qris'); assert.equal(location, undefined); assert.ok(panel.trx.qris_url); assert.ok(scheduled);
  console.log('PASS: QRIS displays automatically and unpaid counter does not redirect');
  await scheduled(); assert.ok(calls.includes('/pembayaran/status')); assert.equal(location, '/ggmart/admin/kasir');
  assert.ok(!calls.includes('/transaksi/konfirmasi'));
  console.log('PASS: Automatic status check returns to cashier only after server completes sale');
  panel.destroy(); assert.equal(scheduled, null);
  stage = 'expired'; location = undefined; calls = [];
  const expired = context.paymentPanel(); expired.$dispatch = () => {}; await expired.init(); assert.equal(location, undefined); assert.equal(scheduled, null); assert.equal(calls.length, 0);
  console.log('PASS: Expired QRIS stops polling without completing or redirecting');
}
run().catch(error => { console.error(error); process.exitCode = 1; });

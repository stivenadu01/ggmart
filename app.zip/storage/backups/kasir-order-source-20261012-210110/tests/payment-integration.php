<?php
require __DIR__ . '/../scripts/bootstrap.php';
function verifyCheck(bool $ok,string $name): void { if (!$ok) throw new RuntimeException($name); echo "PASS: $name\n"; }
function paymentCall(string $url,array $session,string $method='GET',?array $body=null,bool $file=false): array
{
  $ch=curl_init(BASE_URL . $url);
  $headers=['Accept: application/json','Cookie: ggmart_session=' . $session['id'],'X-CSRF-Token: ' . $session['csrf']];
  if ($body!==null) { if (!$file) $headers[]='Content-Type: application/json'; curl_setopt($ch,CURLOPT_POSTFIELDS,$file ? $body : json_encode($body)); }
  curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_HTTPHEADER=>$headers,CURLOPT_TIMEOUT=>30]);
  $raw=curl_exec($ch); $status=curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch); return [$status,json_decode($raw,true),$raw];
}
ini_set('session.use_cookies','0'); session_cache_limiter(''); session_name('ggmart_session');
$users=[]; $sessions=[]; $codes=[]; $cart=[]; $upload=ROOT_PATH . '/storage/proof-check-' . bin2hex(random_bytes(4)) . '.png';
$customer=oq("SELECT * FROM pengguna WHERE role='pelanggan' LIMIT 1")->fetch_assoc();
$product=oq('SELECT * FROM produk WHERE stok>5 AND harga_jual>0 ORDER BY kode_produk LIMIT 1')->fetch_assoc();
$zone=oq("SELECT * FROM zona_pengiriman WHERE kelurahan='Fatululi'")->fetch_assoc();
if (!$customer || !$product || !$zone) throw new RuntimeException('Existing customer/product/zone required.');
$cart=oq('SELECT * FROM keranjang WHERE id_pengguna=?',[$customer['id_pengguna']])->fetch_all(MYSQLI_ASSOC);
$before=['stock'=>(int)$product['stok'],'sold'=>(int)$product['terjual'],'users'=>(int)oq('SELECT COUNT(*) n FROM pengguna')->fetch_assoc()['n'],'trx'=>(int)oq('SELECT COUNT(*) n FROM transaksi')->fetch_assoc()['n']];
try {
  foreach (['admin','pelanggan'] as $role) {
    $user=oq('SELECT id_pengguna,nama,role,no_hp,alamat,email FROM pengguna WHERE role=? LIMIT 1',[$role])->fetch_assoc();
    session_id(bin2hex(random_bytes(16))); session_start(); $token=bin2hex(random_bytes(32));
    $_SESSION=['user'=>$user,'csrf_token'=>$token,'_last_activity'=>time(),'_last_regenerated'=>time()];
    $sessions[$role]=['id'=>session_id(),'csrf'=>$token]; session_write_close();
  }
  // Key hanya di proses CLI, tanpa charge/HTTP Midtrans atau perubahan .env.
  $_ENV['MIDTRANS_SERVER_KEY']='local-test-no-gateway';
  $payload=['metode_bayar'=>'qris','checkout_key'=>bin2hex(random_bytes(16)),'detail'=>[['kode_produk'=>$product['kode_produk'],'jumlah'=>1]],'total_harga'=>(float)$product['harga_jual'],'metode_pengiriman'=>'kirim','kecamatan'=>$zone['kecamatan'],'zona_id'=>$zone['id'],'ongkir'=>1,'nama_penerima'=>$customer['nama'],'no_hp_penerima'=>'081234567890','alamat_pengiriman'=>'Jl. S. K. Lerik, Kelurahan Fatululi, Kota Kupang'];
  try { createOrder(array_replace($payload,['kecamatan'=>'Alak']),$customer); throw new RuntimeException('Wrong district accepted'); } catch (Exception $e) { verifyCheck($e->getCode()===422,'Kelurahan must belong to selected kecamatan'); }
  try { createOrder(array_replace($payload,['total_harga'=>1]),$customer); throw new RuntimeException('Client price accepted'); } catch (Exception $e) { verifyCheck($e->getCode()===409,'Manipulated goods price rejected'); }
  $code=createOrder($payload,$customer); $codes[]=$code;
  verifyCheck(createOrder($payload,$customer)===$code,'Repeated checkout returns same order');
  $trx=orderRow($code);
  verifyCheck((float)$trx['ongkir']===(float)$zone['tarif'] && (float)$trx['total_tagihan']===(float)$product['harga_jual']+(float)$zone['tarif'],'Server controls shipping and grand total');
  verifyCheck((int)oq('SELECT stok FROM produk WHERE kode_produk=?',[$product['kode_produk']])->fetch_assoc()['stok']===$before['stock']-1,'Checkout reserves stock exactly once');
  db()->begin_transaction(); oq('UPDATE zona_pengiriman SET tarif=tarif+5000 WHERE id=?',[$zone['id']]);
  verifyCheck((float)orderRow($code)['ongkir']===(float)$zone['tarif'],'Old order keeps its shipping rate'); db()->rollback();
  oq("UPDATE transaksi SET metode_bayar='transfer' WHERE kode_transaksi=?",[$code]);
  [$status]=paymentCall('/api/transaksi/proses',$sessions['admin'],'POST',['kode_transaksi'=>$code]); verifyCheck($status===409,'Admin cannot process unpaid order');
  file_put_contents($upload,base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aWQAAAABJRU5ErkJggg=='));
  $body=['kode_transaksi'=>$code,'bukti'=>new CURLFile($upload,'image/png','transfer.png')];
  [$status]=paymentCall('/api/pembayaran/bukti',$sessions['pelanggan'],'POST',$body,true); verifyCheck($status===200 && orderRow($code)['status_bayar']==='menunggu_verifikasi','Customer uploads image proof');
  [$status]=paymentCall('/api/pembayaran/bukti/' . $code,$sessions['admin']); verifyCheck($status===200,'Admin can read private proof');
  [$status]=paymentCall('/api/pembayaran/verifikasi',$sessions['admin'],'POST',['kode_transaksi'=>$code,'aksi'=>'tolak','catatan'=>'Nominal belum terlihat jelas.']); verifyCheck($status===200 && orderRow($code)['status_bayar']==='ditolak','Admin rejection requires resubmission');
  [$status]=paymentCall('/api/pembayaran/bukti',$sessions['pelanggan'],'POST',$body,true); verifyCheck($status===200,'Customer can upload proof again');
  [$status]=paymentCall('/api/pembayaran/verifikasi',$sessions['admin'],'POST',['kode_transaksi'=>$code,'aksi'=>'terima']); verifyCheck($status===200 && orderRow($code)['status_bayar']==='lunas','Admin accepts manual transfer');
  [$status]=paymentCall('/api/transaksi/proses',$sessions['admin'],'POST',['kode_transaksi'=>$code]); verifyCheck($status===200,'Paid order can be processed');
  [$status]=paymentCall('/api/transaksi/konfirmasi',$sessions['admin'],'POST',['kode_transaksi'=>$code]); verifyCheck($status===409,'Delivery cannot complete before dispatch');
  [$status]=paymentCall('/api/transaksi/kirim',$sessions['admin'],'POST',['kode_transaksi'=>$code]); verifyCheck($status===200 && orderRow($code)['status']==='dikirim','Admin dispatches local delivery');
  [$status]=paymentCall('/api/transaksi/konfirmasi',$sessions['admin'],'POST',['kode_transaksi'=>$code]); verifyCheck($status===200 && orderRow($code)['status']==='selesai','Delivery completion records sale');
  $ledger=(int)oq("SELECT COUNT(*) n FROM mutasi_stok WHERE kode_transaksi=? AND type='keluar'",[$code])->fetch_assoc()['n'];
  [$status]=paymentCall('/api/transaksi/konfirmasi',$sessions['admin'],'POST',['kode_transaksi'=>$code]); verifyCheck($status===200 && (int)oq("SELECT COUNT(*) n FROM mutasi_stok WHERE kode_transaksi=? AND type='keluar'",[$code])->fetch_assoc()['n']===$ledger,'Repeated completion cannot consume stock again');
  [$status]=paymentCall('/api/transaksi/batal',$sessions['admin'],'POST',['kode_transaksi'=>$code]); verifyCheck($status===200 && orderRow($code)['status_bayar']==='perlu_refund','Paid cancellation restores stock and requires refund');
  [$status]=paymentCall('/api/pembayaran/refund',$sessions['admin'],'POST',['kode_transaksi'=>$code,'catatan'=>'Pengembalian dana telah dicatat untuk pemeriksaan.']); verifyCheck($status===200 && orderRow($code)['status_bayar']==='dikembalikan','Admin records completed refund');
} finally {
  // Hapus hanya kode acak yang dibuat proses ini, setelah mengembalikan stok.
  foreach ($codes as $code) {
    db()->begin_transaction();
    try {
      $trx=orderRow($code,true); if ($trx && $trx['status']!=='dibatalkan') cancelOrder($code);
      $proof=$trx['bukti_bayar'] ?? null;
      oq('DELETE FROM alokasi_stok WHERE kode_transaksi=?',[$code]);
      oq('DELETE FROM mutasi_stok WHERE kode_transaksi=?',[$code]);
      oq('DELETE FROM detail_transaksi WHERE kode_transaksi=?',[$code]);
      oq('DELETE FROM riwayat_pembayaran WHERE kode_transaksi=?',[$code]);
      oq('DELETE FROM reservasi_stok WHERE kode_transaksi=?',[$code]);
      oq('DELETE FROM transaksi WHERE kode_transaksi=?',[$code]); db()->commit();
      if ($proof && preg_match('/^[a-f0-9]{40}\.(png|jpg|webp)$/',$proof)) @unlink(ROOT_PATH . '/storage/bukti/' . $proof);
    } catch (Throwable $e) { db()->rollback(); throw $e; }
  }
  foreach ($cart as $item) oq('INSERT IGNORE INTO keranjang(id_keranjang,id_pengguna,kode_produk,jumlah) VALUES (?,?,?,?)',[$item['id_keranjang'],$item['id_pengguna'],$item['kode_produk'],$item['jumlah']]);
  foreach ($sessions as $session) { session_id($session['id']); session_start(); $_SESSION=[]; session_destroy(); }
  if (is_file($upload)) unlink($upload);
}
$after=oq('SELECT stok,terjual FROM produk WHERE kode_produk=?',[$product['kode_produk']])->fetch_assoc();
verifyCheck((int)$after['stok']===$before['stock'] && (int)$after['terjual']===$before['sold'],'Original stock and sales restored');
verifyCheck((int)oq('SELECT COUNT(*) n FROM transaksi')->fetch_assoc()['n']===$before['trx'] && (int)oq('SELECT COUNT(*) n FROM pengguna')->fetch_assoc()['n']===$before['users'],'Test adds no permanent transactions or users');
echo "Payment checks completed and temporary rows removed.\n";

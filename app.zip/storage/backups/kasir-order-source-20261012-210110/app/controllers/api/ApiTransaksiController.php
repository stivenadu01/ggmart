<?php
class ApiTransaksiController
{
  public function __construct() { model('Transaksi'); model('DetailTransaksi'); expireOrders(); }
  public function list()
  {
    try {
      $page=max(1,(int)query('page',1)); $limit=max(1,min(100,(int)query('limit',10)));
      $user=$_SESSION['user'];
      $owner=in_array($user['role'],['admin','pimpinan'],true) ? query('user') : $user['id_pengguna'];
      $source=query('sumber'); $stage=query('tahap');
      if ($source!==null && !in_array($source,['online','kasir'],true)) throw new Exception('Jenis transaksi tidak valid.',422);
      if ($stage!==null && !in_array($stage,['menunggu_pembayaran','diproses','dikirim','selesai','dibatalkan'],true)) throw new Exception('Tahap pesanan tidak valid.',422);
      [$data,$total,$summary]=getTransaksiList($page,$limit,trim(query('search','')),query('start'),query('end'),query('metode'),$owner,query('status'),$stage,$source);
      foreach ($data as &$row) unset($row['checkout_key'],$row['bukti_bayar']);
      unset($row);
      response(['success'=>true,'data'=>$data,'totalSummary'=>$summary,'pagination'=>['page'=>$page,'limit'=>$limit,'total'=>$total,'total_pages'=>max(1,ceil($total/$limit))]]);
    } catch (Throwable $e) { orderError($e); }
  }
  public function detail()
  {
    try {
      $trx=$this->accessible(trim(query('k','')));
      $trx['detail']=getDetailTransaksi($trx['kode_transaksi']);
      $trx['riwayat_pembayaran']=oq('SELECT status,catatan,tanggal FROM riwayat_pembayaran WHERE kode_transaksi=? ORDER BY id',[$trx['kode_transaksi']])->fetch_all(MYSQLI_ASSOC);
      $trx['rekening']=storeSettings();
      $trx['bukti_url']=$trx['bukti_bayar'] ? BASE_URL . '/api/pembayaran/bukti/' . rawurlencode($trx['kode_transaksi']) : null;
      unset($trx['bukti_bayar'],$trx['checkout_key']);
      response(['success'=>true,'data'=>$trx]);
    } catch (Throwable $e) { orderError($e); }
  }
  public function accessible(string $code): array
  {
    $trx=orderRow($code);
    if (!$trx) throw new Exception('Transaksi tidak ditemukan.',404);
    $user=$_SESSION['user'];
    if (!in_array($user['role'],['admin','pimpinan'],true) && (int)$trx['id_pengguna']!==(int)$user['id_pengguna']) throw new Exception('Anda tidak memiliki akses ke transaksi ini.',403);
    return $trx;
  }
  public function tambah_transaksi() { $this->create(true); }
  public function tambah_transaksi_user() { $this->create(false); }
  private function create(bool $cashier): void
  {
    try { $code=createOrder(input(),$_SESSION['user'],$cashier); response(['success'=>true,'message'=>$cashier ? 'Transaksi tersimpan.' : 'Pesanan dibuat. Silakan lanjutkan pembayaran.','data'=>$code],201); }
    catch (Throwable $e) { orderError($e); }
  }
  public function proses_transaksi() { $this->change('proses'); }
  public function kirim_transaksi() { $this->change('kirim'); }
  public function siap_ambil() { $this->change('siap-ambil'); }
  public function konfirmasi_transaksi() { $this->change('selesai'); }
  public function batal_transaksi() { $this->change('batal'); }
  public function batal_transaksi_pending() { $this->change('batal',true); }
  private function change(string $action,bool $customer=false): void
  {
    try {
      $code=trim((string)input('kode_transaksi',''));
      $trx=$this->accessible($code);
      if ($action==='batal' && $trx['metode_bayar']==='qris' && $trx['midtrans_order_id'] && !in_array($trx['status_bayar'],['lunas','perlu_refund','dikembalikan','kedaluwarsa'],true)) {
        if ($trx['midtrans_env']!==midtransEnvironment()) throw new Exception('Lingkungan Midtrans berbeda. Hubungi pengelola.',409);
        $payload=midtransRequest(rawurlencode($trx['midtrans_order_id']) . '/status');
        if (($payload['transaction_status'] ?? '')==='pending') {
          midtransRequest(rawurlencode($trx['midtrans_order_id']) . '/cancel','POST');
          $payload=midtransRequest(rawurlencode($trx['midtrans_order_id']) . '/status');
          if (($payload['transaction_status'] ?? '')==='pending') throw new Exception('QRIS belum berhasil dibatalkan. Coba kembali.',409);
        }
        if ((string)($payload['status_code'] ?? '')!=='404') syncMidtrans($payload);
      }
      db()->begin_transaction();
      try {
        $trx=orderRow($code,true);
        if ($customer && (int)$trx['id_pengguna']!==(int)$_SESSION['user']['id_pengguna']) throw new Exception('Akses ditolak.',403);
        if ($action==='proses') {
          if ($trx['status']!=='pending' || $trx['status_bayar']!=='lunas') throw new Exception('Pesanan harus sudah lunas sebelum diproses.',409);
          oq("UPDATE transaksi SET status='diproses' WHERE kode_transaksi=?",[$code]);
        } elseif ($action==='kirim' || $action==='siap-ambil') {
          if ($trx['status']!=='diproses' || $trx['status_bayar']!=='lunas' || $trx['sumber_transaksi']!=='online') throw new Exception('Pesanan harus lunas dan sedang diproses.',409);
          if ($action==='kirim') {
            if ($trx['metode_pengiriman']!=='kirim') throw new Exception('Pesanan ini diambil di tempat.',409);
            oq("UPDATE transaksi SET status='dikirim',tanggal_kirim=NOW() WHERE kode_transaksi=?",[$code]);
          } else {
            if ($trx['metode_pengiriman']!=='ambil') throw new Exception('Pesanan ini menggunakan pengiriman.',409);
            oq('UPDATE transaksi SET siap_diambil=1 WHERE kode_transaksi=?',[$code]);
          }
        } elseif ($action==='selesai') completeOrder($code);
        else cancelOrder($code,$customer);
        db()->commit();
      } catch (Throwable $e) { db()->rollback(); throw $e; }
      response(['success'=>true,'message'=>['proses'=>'Pesanan diproses.','kirim'=>'Pesanan sedang dikirim.','siap-ambil'=>'Pesanan siap diambil.','selesai'=>'Pesanan selesai dan sudah diterima.','batal'=>'Pesanan dibatalkan.'][$action]]);
    } catch (Throwable $e) { orderError($e); }
  }
  public function badge()
  {
    try { $total=oq("SELECT COUNT(*) total FROM transaksi WHERE sumber_transaksi='online' AND status IN ('pending','diproses','dikirim')")->fetch_assoc()['total']; response(['success'=>true,'data'=>['total'=>(int)$total]]); }
    catch (Throwable $e) { orderError($e); }
  }
}

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS `alokasi_stok`;
CREATE TABLE `alokasi_stok` (
  `kode_transaksi` varchar(15) NOT NULL,
  `id_mutasi` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga_pokok` decimal(12,2) NOT NULL,
  PRIMARY KEY (`kode_transaksi`,`id_mutasi`),
  KEY `id_mutasi` (`id_mutasi`),
  CONSTRAINT `alokasi_stok_ibfk_1` FOREIGN KEY (`kode_transaksi`) REFERENCES `transaksi` (`kode_transaksi`),
  CONSTRAINT `alokasi_stok_ibfk_2` FOREIGN KEY (`id_mutasi`) REFERENCES `mutasi_stok` (`id_mutasi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `alokasi_stok` (`kode_transaksi`,`id_mutasi`,`jumlah`,`harga_pokok`) VALUES ('GG-0423BF783EA9','76','1','45500.00');
INSERT INTO `alokasi_stok` (`kode_transaksi`,`id_mutasi`,`jumlah`,`harga_pokok`) VALUES ('GG-08F3C54E61D1','77','2','31500.00');
INSERT INTO `alokasi_stok` (`kode_transaksi`,`id_mutasi`,`jumlah`,`harga_pokok`) VALUES ('GG-28318AA3CF53','76','1','45500.00');
INSERT INTO `alokasi_stok` (`kode_transaksi`,`id_mutasi`,`jumlah`,`harga_pokok`) VALUES ('GG-3B6DBC7919F6','77','1','31500.00');
INSERT INTO `alokasi_stok` (`kode_transaksi`,`id_mutasi`,`jumlah`,`harga_pokok`) VALUES ('GG-5000AB552B3B','77','1','31500.00');
INSERT INTO `alokasi_stok` (`kode_transaksi`,`id_mutasi`,`jumlah`,`harga_pokok`) VALUES ('GG-5000AB552B3B','78','1','31500.00');
INSERT INTO `alokasi_stok` (`kode_transaksi`,`id_mutasi`,`jumlah`,`harga_pokok`) VALUES ('GG-64AC5C9D9F7B','78','3','31500.00');
INSERT INTO `alokasi_stok` (`kode_transaksi`,`id_mutasi`,`jumlah`,`harga_pokok`) VALUES ('GG-757FE875C94F','78','3','31500.00');
INSERT INTO `alokasi_stok` (`kode_transaksi`,`id_mutasi`,`jumlah`,`harga_pokok`) VALUES ('GG-88BDD71C994D','77','1','31500.00');
INSERT INTO `alokasi_stok` (`kode_transaksi`,`id_mutasi`,`jumlah`,`harga_pokok`) VALUES ('GG-9542E5026F3B','76','1','45500.00');
INSERT INTO `alokasi_stok` (`kode_transaksi`,`id_mutasi`,`jumlah`,`harga_pokok`) VALUES ('GG-A985CD63D2A0','78','3','31500.00');
INSERT INTO `alokasi_stok` (`kode_transaksi`,`id_mutasi`,`jumlah`,`harga_pokok`) VALUES ('GG-F66DE86C0F47','77','2','31500.00');
DROP TABLE IF EXISTS `detail_transaksi`;
CREATE TABLE `detail_transaksi` (
  `id_detail` int(11) NOT NULL AUTO_INCREMENT,
  `kode_transaksi` varchar(15) NOT NULL,
  `kode_produk` varchar(15) DEFAULT NULL,
  `jumlah` int(11) DEFAULT 1,
  `harga_satuan` decimal(12,2) DEFAULT NULL,
  `harga_pokok` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`id_detail`),
  KEY `idx_kode_transaksi` (`kode_transaksi`),
  KEY `idx_kode_produk` (`kode_produk`),
  CONSTRAINT `fk_detail_produk` FOREIGN KEY (`kode_produk`) REFERENCES `produk` (`kode_produk`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_detail_transaksi` FOREIGN KEY (`kode_transaksi`) REFERENCES `transaksi` (`kode_transaksi`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `detail_transaksi` (`id_detail`,`kode_transaksi`,`kode_produk`,`jumlah`,`harga_satuan`,`harga_pokok`) VALUES ('93','GG-0423BF783EA9','PRD_00016875477','1','65000.00','45500.00');
INSERT INTO `detail_transaksi` (`id_detail`,`kode_transaksi`,`kode_produk`,`jumlah`,`harga_satuan`,`harga_pokok`) VALUES ('94','GG-F66DE86C0F47','PRD_00877921510','2','45000.00','31500.00');
INSERT INTO `detail_transaksi` (`id_detail`,`kode_transaksi`,`kode_produk`,`jumlah`,`harga_satuan`,`harga_pokok`) VALUES ('95','GG-64AC5C9D9F7B','PRD_02053183769','3','45000.00','31500.00');
INSERT INTO `detail_transaksi` (`id_detail`,`kode_transaksi`,`kode_produk`,`jumlah`,`harga_satuan`,`harga_pokok`) VALUES ('96','GG-9542E5026F3B','PRD_00016875477','1','65000.00','45500.00');
INSERT INTO `detail_transaksi` (`id_detail`,`kode_transaksi`,`kode_produk`,`jumlah`,`harga_satuan`,`harga_pokok`) VALUES ('97','GG-08F3C54E61D1','PRD_00877921510','2','45000.00','31500.00');
INSERT INTO `detail_transaksi` (`id_detail`,`kode_transaksi`,`kode_produk`,`jumlah`,`harga_satuan`,`harga_pokok`) VALUES ('98','GG-A985CD63D2A0','PRD_02053183769','3','45000.00','31500.00');
INSERT INTO `detail_transaksi` (`id_detail`,`kode_transaksi`,`kode_produk`,`jumlah`,`harga_satuan`,`harga_pokok`) VALUES ('99','GG-28318AA3CF53','PRD_00016875477','1','65000.00','45500.00');
INSERT INTO `detail_transaksi` (`id_detail`,`kode_transaksi`,`kode_produk`,`jumlah`,`harga_satuan`,`harga_pokok`) VALUES ('100','GG-7CDDC6D37F3E','PRD_00877921510','2','45000.00','0.00');
INSERT INTO `detail_transaksi` (`id_detail`,`kode_transaksi`,`kode_produk`,`jumlah`,`harga_satuan`,`harga_pokok`) VALUES ('101','GG-757FE875C94F','PRD_02053183769','3','45000.00','31500.00');
INSERT INTO `detail_transaksi` (`id_detail`,`kode_transaksi`,`kode_produk`,`jumlah`,`harga_satuan`,`harga_pokok`) VALUES ('102','GG-73D4D10DCAA1','PRD_00016875477','1','65000.00','0.00');
INSERT INTO `detail_transaksi` (`id_detail`,`kode_transaksi`,`kode_produk`,`jumlah`,`harga_satuan`,`harga_pokok`) VALUES ('105','GG-9D68EBB6D777','PRD_00016875477','1','65000.00','0.00');
INSERT INTO `detail_transaksi` (`id_detail`,`kode_transaksi`,`kode_produk`,`jumlah`,`harga_satuan`,`harga_pokok`) VALUES ('106','GG-9D68EBB6D777','PRD_00877921510','1','45000.00','0.00');
INSERT INTO `detail_transaksi` (`id_detail`,`kode_transaksi`,`kode_produk`,`jumlah`,`harga_satuan`,`harga_pokok`) VALUES ('112','GG-BC4714506D05','PRD_02053183769','1','45000.00','0.00');
INSERT INTO `detail_transaksi` (`id_detail`,`kode_transaksi`,`kode_produk`,`jumlah`,`harga_satuan`,`harga_pokok`) VALUES ('113','GG-88BDD71C994D','PRD_00877921510','1','45000.00','31500.00');
INSERT INTO `detail_transaksi` (`id_detail`,`kode_transaksi`,`kode_produk`,`jumlah`,`harga_satuan`,`harga_pokok`) VALUES ('114','GG-5000AB552B3B','PRD_00877921510','1','45000.00','31500.00');
INSERT INTO `detail_transaksi` (`id_detail`,`kode_transaksi`,`kode_produk`,`jumlah`,`harga_satuan`,`harga_pokok`) VALUES ('115','GG-5000AB552B3B','PRD_02053183769','1','45000.00','31500.00');
INSERT INTO `detail_transaksi` (`id_detail`,`kode_transaksi`,`kode_produk`,`jumlah`,`harga_satuan`,`harga_pokok`) VALUES ('116','GG-3B6DBC7919F6','PRD_00877921510','1','45000.00','31500.00');
DROP TABLE IF EXISTS `kategori`;
CREATE TABLE `kategori` (
  `id_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(100) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  PRIMARY KEY (`id_kategori`),
  KEY `idx_id_kategori` (`id_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `kategori` (`id_kategori`,`nama_kategori`,`deskripsi`) VALUES ('76','Beras & Pangan Pokok','Produk beras lokal, jagung, kacang, dan bahan pokok lainnya.');
INSERT INTO `kategori` (`id_kategori`,`nama_kategori`,`deskripsi`) VALUES ('77','Minyak & Bumbu Dapur','Minyak lokal, minyak kelapa, rempah-rempah, garam, gula, dan bumbu.');
INSERT INTO `kategori` (`id_kategori`,`nama_kategori`,`deskripsi`) VALUES ('78','Kopi & Minuman','Kopi lokal NTT, teh herbal, minuman tradisional, dan olahan minuman lainnya.');
INSERT INTO `kategori` (`id_kategori`,`nama_kategori`,`deskripsi`) VALUES ('79','Madu & Herbal','Madu hutan, jahe, minyak kemiri, dan produk kesehatan tradisional.');
INSERT INTO `kategori` (`id_kategori`,`nama_kategori`,`deskripsi`) VALUES ('80','Camilan & Snack','Kerupuk, abon ikan, keripik singkong, dan makanan ringan.');
INSERT INTO `kategori` (`id_kategori`,`nama_kategori`,`deskripsi`) VALUES ('82','Kerajinan & Tenun','Tenun ikat, souvenir lokal, dan kerajinan tangan khas NTT.\n\n\nxxdnfsaj');
INSERT INTO `kategori` (`id_kategori`,`nama_kategori`,`deskripsi`) VALUES ('84','Sayur & Produk Segar','Sayuran segar dari petani lokal.');
INSERT INTO `kategori` (`id_kategori`,`nama_kategori`,`deskripsi`) VALUES ('85','Frozen Food','Makanan beku dan olahan penyimpanan dingin.');
DROP TABLE IF EXISTS `keranjang`;
CREATE TABLE `keranjang` (
  `id_keranjang` int(11) NOT NULL AUTO_INCREMENT,
  `id_pengguna` int(11) NOT NULL,
  `kode_produk` varchar(15) DEFAULT NULL,
  `jumlah` int(11) DEFAULT 1,
  PRIMARY KEY (`id_keranjang`),
  KEY `fk_keranjang_user` (`id_pengguna`),
  KEY `fk_keranjang_produk` (`kode_produk`),
  CONSTRAINT `fk_keranjang_produk` FOREIGN KEY (`kode_produk`) REFERENCES `produk` (`kode_produk`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_keranjang_user` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id_pengguna`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=238 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `mutasi_stok`;
CREATE TABLE `mutasi_stok` (
  `id_mutasi` int(11) NOT NULL AUTO_INCREMENT,
  `kode_produk` varchar(15) DEFAULT NULL,
  `type` enum('masuk','keluar') NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga_pokok` decimal(12,2) DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `sisa_stok` int(11) DEFAULT NULL,
  `tanggal` datetime DEFAULT current_timestamp(),
  `kode_transaksi` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id_mutasi`),
  KEY `kode_produk` (`kode_produk`),
  KEY `idx_tanggal` (`tanggal`),
  CONSTRAINT `mutasi_stok_ibfk_1` FOREIGN KEY (`kode_produk`) REFERENCES `produk` (`kode_produk`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `mutasi_stok` (`id_mutasi`,`kode_produk`,`type`,`jumlah`,`harga_pokok`,`keterangan`,`sisa_stok`,`tanggal`,`kode_transaksi`) VALUES ('70','PRD_00016875477','masuk','50','60000.00','','50','2026-10-12 17:36:10',NULL);
INSERT INTO `mutasi_stok` (`id_mutasi`,`kode_produk`,`type`,`jumlah`,`harga_pokok`,`keterangan`,`sisa_stok`,`tanggal`,`kode_transaksi`) VALUES ('76','PRD_00016875477','masuk','30','45500.00','Penerimaan persediaan','27','2026-09-02 08:00:00',NULL);
INSERT INTO `mutasi_stok` (`id_mutasi`,`kode_produk`,`type`,`jumlah`,`harga_pokok`,`keterangan`,`sisa_stok`,`tanggal`,`kode_transaksi`) VALUES ('77','PRD_00877921510','masuk','30','31500.00','Penerimaan persediaan','23','2026-09-02 08:00:00',NULL);
INSERT INTO `mutasi_stok` (`id_mutasi`,`kode_produk`,`type`,`jumlah`,`harga_pokok`,`keterangan`,`sisa_stok`,`tanggal`,`kode_transaksi`) VALUES ('78','PRD_02053183769','masuk','30','31500.00','Penerimaan persediaan','20','2026-09-02 08:00:00',NULL);
INSERT INTO `mutasi_stok` (`id_mutasi`,`kode_produk`,`type`,`jumlah`,`harga_pokok`,`keterangan`,`sisa_stok`,`tanggal`,`kode_transaksi`) VALUES ('79','PRD_00016875477','keluar','1','45500.00','Penjualan GG-0423BF783EA9',NULL,'2026-10-12 09:15:00','GG-0423BF783EA9');
INSERT INTO `mutasi_stok` (`id_mutasi`,`kode_produk`,`type`,`jumlah`,`harga_pokok`,`keterangan`,`sisa_stok`,`tanggal`,`kode_transaksi`) VALUES ('80','PRD_00877921510','keluar','2','31500.00','Penjualan GG-F66DE86C0F47',NULL,'2026-10-11 10:15:00','GG-F66DE86C0F47');
INSERT INTO `mutasi_stok` (`id_mutasi`,`kode_produk`,`type`,`jumlah`,`harga_pokok`,`keterangan`,`sisa_stok`,`tanggal`,`kode_transaksi`) VALUES ('81','PRD_02053183769','keluar','3','31500.00','Penjualan GG-64AC5C9D9F7B',NULL,'2026-10-10 11:15:00','GG-64AC5C9D9F7B');
INSERT INTO `mutasi_stok` (`id_mutasi`,`kode_produk`,`type`,`jumlah`,`harga_pokok`,`keterangan`,`sisa_stok`,`tanggal`,`kode_transaksi`) VALUES ('82','PRD_00016875477','keluar','1','45500.00','Penjualan GG-9542E5026F3B',NULL,'2026-10-09 12:15:00','GG-9542E5026F3B');
INSERT INTO `mutasi_stok` (`id_mutasi`,`kode_produk`,`type`,`jumlah`,`harga_pokok`,`keterangan`,`sisa_stok`,`tanggal`,`kode_transaksi`) VALUES ('83','PRD_00877921510','keluar','2','31500.00','Penjualan GG-08F3C54E61D1',NULL,'2026-10-07 13:15:00','GG-08F3C54E61D1');
INSERT INTO `mutasi_stok` (`id_mutasi`,`kode_produk`,`type`,`jumlah`,`harga_pokok`,`keterangan`,`sisa_stok`,`tanggal`,`kode_transaksi`) VALUES ('84','PRD_02053183769','keluar','3','31500.00','Penjualan GG-A985CD63D2A0',NULL,'2026-09-30 14:15:00','GG-A985CD63D2A0');
INSERT INTO `mutasi_stok` (`id_mutasi`,`kode_produk`,`type`,`jumlah`,`harga_pokok`,`keterangan`,`sisa_stok`,`tanggal`,`kode_transaksi`) VALUES ('85','PRD_00016875477','keluar','1','45500.00','Penjualan GG-28318AA3CF53',NULL,'2026-09-09 15:15:00','GG-28318AA3CF53');
INSERT INTO `mutasi_stok` (`id_mutasi`,`kode_produk`,`type`,`jumlah`,`harga_pokok`,`keterangan`,`sisa_stok`,`tanggal`,`kode_transaksi`) VALUES ('90','PRD_02053183769','keluar','3','31500.00','Penjualan GG-757FE875C94F',NULL,'2026-10-12 19:06:35','GG-757FE875C94F');
INSERT INTO `mutasi_stok` (`id_mutasi`,`kode_produk`,`type`,`jumlah`,`harga_pokok`,`keterangan`,`sisa_stok`,`tanggal`,`kode_transaksi`) VALUES ('98','PRD_00877921510','keluar','1','31500.00','Penjualan GG-88BDD71C994D',NULL,'2026-10-12 19:41:55','GG-88BDD71C994D');
INSERT INTO `mutasi_stok` (`id_mutasi`,`kode_produk`,`type`,`jumlah`,`harga_pokok`,`keterangan`,`sisa_stok`,`tanggal`,`kode_transaksi`) VALUES ('99','PRD_00877921510','keluar','1','31500.00','Penjualan GG-5000AB552B3B',NULL,'2026-10-12 19:44:43','GG-5000AB552B3B');
INSERT INTO `mutasi_stok` (`id_mutasi`,`kode_produk`,`type`,`jumlah`,`harga_pokok`,`keterangan`,`sisa_stok`,`tanggal`,`kode_transaksi`) VALUES ('100','PRD_02053183769','keluar','1','31500.00','Penjualan GG-5000AB552B3B',NULL,'2026-10-12 19:44:43','GG-5000AB552B3B');
INSERT INTO `mutasi_stok` (`id_mutasi`,`kode_produk`,`type`,`jumlah`,`harga_pokok`,`keterangan`,`sisa_stok`,`tanggal`,`kode_transaksi`) VALUES ('101','PRD_00877921510','keluar','1','31500.00','Penjualan GG-3B6DBC7919F6',NULL,'2026-10-12 19:45:22','GG-3B6DBC7919F6');
DROP TABLE IF EXISTS `pengaturan`;
CREATE TABLE `pengaturan` (
  `nama` varchar(80) NOT NULL,
  `nilai` text NOT NULL,
  PRIMARY KEY (`nama`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `pengguna`;
CREATE TABLE `pengguna` (
  `id_pengguna` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `no_hp` varchar(15) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('pelanggan','admin','kasir','pimpinan') NOT NULL,
  `tanggal_dibuat` datetime DEFAULT current_timestamp(),
  `is_verified` tinyint(1) DEFAULT 0,
  `verify_token` varchar(255) DEFAULT NULL,
  `token_expired` datetime DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_expired` datetime DEFAULT NULL,
  PRIMARY KEY (`id_pengguna`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_email` (`email`),
  KEY `idx_id_user` (`id_pengguna`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `pengguna` (`id_pengguna`,`nama`,`email`,`no_hp`,`alamat`,`password`,`role`,`tanggal_dibuat`,`is_verified`,`verify_token`,`token_expired`,`reset_token`,`reset_expired`) VALUES ('1','admin','admin@gmail.com','081338609228','Jln Nasution II, Kayu Puith, Kupang NTT','$2y$10$.XpEs.z7h5xt68V8cua9o.c6iu5fBbfZvd6giRTExPT6GWS7.5zlS','admin','2025-10-21 20:01:46','1',NULL,'2026-05-22 15:58:20',NULL,NULL);
INSERT INTO `pengguna` (`id_pengguna`,`nama`,`email`,`no_hp`,`alamat`,`password`,`role`,`tanggal_dibuat`,`is_verified`,`verify_token`,`token_expired`,`reset_token`,`reset_expired`) VALUES ('12','pimpinan','pimpinan@gmail.com','081338609228','Jln A.H Nasution 3','$2y$10$Qb6CXUHFwA2DcPTKb7bq9OeEjZUpLbTdlVxLjd.9.wfWRknXv4bzq','pimpinan','2026-06-01 23:07:02','1',NULL,'2026-06-02 23:07:02',NULL,NULL);
INSERT INTO `pengguna` (`id_pengguna`,`nama`,`email`,`no_hp`,`alamat`,`password`,`role`,`tanggal_dibuat`,`is_verified`,`verify_token`,`token_expired`,`reset_token`,`reset_expired`) VALUES ('22','pelanggan','pelanggan@gmail.com','085829230787','Jl Perintis Kemerdekaan 1','$2y$10$SoOgXtN1GUDpg5szQJmT.OM97MleZeG8ZgsKIx78vHU33or.bxiqu','pelanggan','2026-08-21 23:39:59','1',NULL,NULL,NULL,NULL);
INSERT INTO `pengguna` (`id_pengguna`,`nama`,`email`,`no_hp`,`alamat`,`password`,`role`,`tanggal_dibuat`,`is_verified`,`verify_token`,`token_expired`,`reset_token`,`reset_expired`) VALUES ('23','kasir','kasir@gmail.com','085000000000',NULL,'$2y$10$qa.LLO4k79KSjBR8nCmaU.sG/qTETrxYsXZSzbYpNviDdcoOutGCy','kasir','2026-08-31 22:43:52','1','6dfccd52c5e1be32a179e654d6da7d55006e6cdaf0c12349f8d6c5dddc050932','2026-09-01 22:43:52',NULL,NULL);
DROP TABLE IF EXISTS `produk`;
CREATE TABLE `produk` (
  `kode_produk` varchar(15) NOT NULL,
  `id_kategori` int(11) DEFAULT NULL,
  `nama_produk` varchar(150) NOT NULL,
  `harga_jual` decimal(12,2) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `satuan_dasar` varchar(10) DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `asal_produk` varchar(100) DEFAULT NULL,
  `tagline` varchar(100) DEFAULT NULL,
  `stok` int(11) DEFAULT 0,
  `terjual` int(11) DEFAULT 0,
  `tanggal_dibuat` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`kode_produk`),
  KEY `idx_kode_produk` (`kode_produk`),
  KEY `idx_nama_produk` (`nama_produk`),
  KEY `idx_id_kategori` (`id_kategori`),
  KEY `idx_tanggal_dibuat` (`tanggal_dibuat`),
  KEY `idx_produk_penjualan` (`id_kategori`,`terjual`),
  CONSTRAINT `fk_produk_kategori` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id_kategori`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_00016875477','80','CNC COOKIES NASTAR','65000.00','','Toples','/produk/PRD_00016875477.png','CNC COOKIES, PENFUI KUPANG NTT','Nastar CNC renyah, rasa kelapa asli Kupang.','77','3','2025-12-19 12:53:23');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_00877921510','80','CNC COOKIES SAGU KEJU','45000.00','','Toples','/produk/PRD_00877921510.png','CNC COOKIES, PENFUI KUPANG NTT','Rasa gurih keju dengan sentuhan sagu alami, langsung dari Kupang.','23','7','2025-12-19 12:54:49');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_02053183769','80','Kue Coklat Spekuk CNC COOKIES','45000.00','','Toples','/produk/PRD_02053183769.png','CNC COOKIES, PENFUI KUPANG NTT','Spekuk coklat renyah, rasa asli Kupang, cocok ngemil santai.','20','10','2025-12-19 12:56:47');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_02638121216','78','Coca Cola 330 ML','7000.00','','Kaleng','/produk/PRD_02638121216.webp','',NULL,'0','0','2025-12-28 14:17:18');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_03566984797','80','Jagung Pulut Pedas','10000.00','Nikmati kelezatan camilan autentik khas Nusa Tenggara Timur dengan Jagung Pulut Pedas. Terbuat dari jagung pulut (jagung ketan) pilihan yang terkenal dengan teksturnya yang unik—lebih empuk, padat, dan sedikit kenyal saat dikunyah, sangat berbeda dari jagung biasa.','Pcs','/produk/PRD_03566984797.png','Klasis Kota Kupang Barat','Jagung pulut pedas, empuk kenyal, cita rasa khas NTT.','0','0','2025-12-19 12:59:18');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_05304045813','79','Minyak Kemiri','30000.00','','Botol','/produk/PRD_05304045813.png','Pemuda Amanuban Tengah Selatan','Minyak kemiri Pemuda Amanuban, wangi alami, cocok untuk masak sehari-hari.','0','0','2025-12-19 13:02:12');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_06662692105','78','Minuman Perjamuan Perjanjian Baru','75000.00','','Botol','/produk/PRD_06662692105.png','SINODE GMIT','Minuman Perjamuan Perjanjian baru, dari SINODE GMIT.','0','0','2025-12-19 13:04:28');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_07627479596','79','Minyak Kayu Putih Tuamese','35000.00','','Botol','/produk/PRD_07627479596.png','GMIT EBENHAEZER TUAMESE','Minyak kayu putih Tuamese, wangi alami, segar dari Kupang.','0','0','2025-12-19 13:06:04');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_07639457476','78','Pulpy orange 300 ML','7000.00','','Botol','/produk/PRD_07639457476.webp','',NULL,'0','0','2025-12-28 16:32:43');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_08361677758','78','Bear Brand 189 ML','11500.00','','Pcs','/produk/PRD_08361677758.png','',NULL,'0','0','2025-12-28 16:33:56');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_08959734393','78','Fruit Tea Blaccurent 350 ML','7000.00','','Pcs','/produk/PRD_08959734393.jpg','',NULL,'0','0','2025-12-28 16:34:55');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_09433004187','78','Fruit Tea Strobery 350 ML','7000.00','','Botol','/produk/PRD_09433004187.jpg','',NULL,'0','0','2025-12-28 16:35:43');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_09992327462','79','Gula Sabu Putih 350ML','21000.00','Kegunaan:\r\n-Mengatasi sakit lambung\r\n-Mengatasi anemia\r\n-Mengatasi nafsu makan yang kurang normal\r\n-Dapat meresahkan lambung, kronis dll','Botol','/produk/PRD_09992327462.png','Air Nona, Kota Raja Kota Kupang','Gula Sabu alami, bantu atasi lambung dan tambah selera makan.','0','0','2025-12-19 13:10:01');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_10996118655','79','Madu Batu','40000.00','','Botol','/produk/PRD_10996118655.png','Klasis Semau','Madu Batu Klasis Semau, manis alami khas Kupang.','0','0','2025-12-19 13:11:41');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_11650264519','79','Madu Pohon','40000.00','','Botol','/produk/PRD_11650264519.png','Amfoang Selatan','Rasa manis alami khas Amfoang','0','0','2025-12-19 13:12:46');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_11779732260','78','Dancow Coklat','5000.00','','Sachet','/produk/PRD_11779732260.jpg','',NULL,'0','0','2025-12-28 16:49:39');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_12267226394','78','Teh Botol Sosro 350 ML','7000.00','','Botol','/produk/PRD_12267226394.webp','',NULL,'0','0','2025-12-28 16:40:26');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_12761562947','78','Buavita 245 ML','8500.00','','Pcs','/produk/PRD_12761562947.jpg','',NULL,'0','0','2025-12-28 16:41:16');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_13359265350','78','Nipis Madu 330 ML','5500.00','','Botol','/produk/PRD_13359265350.png','',NULL,'0','0','2025-12-28 16:42:15');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_13699127602','78','Good Day 250 ML','7500.00','','Botol','/produk/PRD_13699127602.jpg','',NULL,'0','0','2025-12-28 16:42:49');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_13763803432','77','Kunyit Asam Instan','20000.00','','Pcs','/produk/PRD_13763803432.png','Jemaat Fatubena','Kunyit Asam Instan Jemaat Fatubena, rasa tradisional siap saji.','0','0','2025-12-19 11:09:25');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_14080726422','78','Floridina Jeruk 350 ML','5000.00','','Botol','/produk/PRD_14080726422.jpg','',NULL,'0','0','2025-12-28 16:43:28');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_14954711260','78','Golda Coffee 200 ML','5500.00','','Botol','/produk/PRD_14954711260.jpg','',NULL,'0','0','2025-12-28 16:44:55');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_15650276204','78','Chocolatos Drink','3000.00','','Shachet','/produk/PRD_15650276204.jpg','',NULL,'0','0','2025-12-28 16:46:05');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_16805975959','78','Good Day','3500.00','','Sachet','/produk/PRD_16805975959.png','',NULL,'0','0','2025-12-28 16:48:00');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_17324769388','78','Dancow Putih','5000.00','','Sachet','/produk/PRD_17324769388.jpg','',NULL,'0','0','2025-12-28 16:48:52');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_18129502243','78','Energen Coklat','3000.00','','Sachet','/produk/PRD_18129502243.jpg','',NULL,'0','0','2025-12-28 16:50:12');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_18617013290','78','Energen Vanila','3000.00','','Sachet','/produk/PRD_18617013290.jpg','',NULL,'0','0','2025-12-28 16:51:01');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_18639457606','78','Aguamor','500.00','','Gelas','/produk/PRD_18639457606.png','','','0','0','2025-12-28 14:04:23');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_18974646805','78','Top Coffee Susu','2000.00','','Sachet','/produk/PRD_18974646805.jpg','',NULL,'0','0','2025-12-28 16:51:37');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_19493878708','78','Kapal Api','2500.00','','Sachet','/produk/PRD_19493878708.webp','',NULL,'0','0','2025-12-28 16:52:30');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_20037601647','78','Top Coffee Gula Aren','2500.00','Top Coffee Gula Aren adalah varian kopi instan 3-in-1 dari Wings Food yang memadukan kekuatan rasa kopi tubruk asli, kelembutan susu, dan legitnya gula aren alami. Produk inovatif ini dirancang bagi generasi modern yang menyukai tren kopi susu ala kafe, namun menginginkan kepraktisan dan harga yang ekonomis dalam format sachet.Berikut adalah rincian deskripsi produk lengkap untuk kebutuhan penjualan, katalog, atau promosi:🌟 Keunggulan ProdukKombinasi Karakter Kuat: Menggunakan racikan biji kopi Robusta dan Arabika pilihan untuk menghasilkan aroma harum yang kompleks dan rasa kopi yang mantap.Sentuhan Gula Aren Asli: Memberikan sensasi rasa manis yang legit, lembut di tenggorokan, khas, dan tidak membuat enek.Ampas Kopi yang Halus: Memiliki tekstur serbuk kopi tubruk mikro yang halus, sehingga sensasi strong kopinya langsung terasa tanpa perlu menunggu ampas turun lama.Fleksibel Disajikan: Sangat nikmat diseduh hangat sebagai teman beraktivitas maupun disajikan dingin dengan es batu untuk kesegaran maksimal.📝 Spesifikasi & KomposisiJenis Produk: Kopi Instan Susu + Gula Aren.Komposisi: Gula, krimer nabati, kopi bubuk instan (9,6%), susu skim bubuk, perisa sintetik, garam, serta pemanis buatan (Asesulfam-K, Sukralosa).Berat per Sachet: 22 gram.Informasi Nilai Gizi: Mengandung sekitar 100 kalori, 2,5 gram lemak, dan 18 gram karbohidrat per sachet.Kemasan di Pasaran: Tersedia dalam bentuk pouch (isi 6+3 sachet) maupun kemasan renteng (isi 15 sachet).☕ Cara Penyajian ResmiSajian Panas: Tuangkan 1 sachet ke dalam cangkir, seduh dengan 150 ml air panas, lalu aduk rata.Sajian Dingin (Es Kopi): Tuangkan 1 sachet ke dalam gelas, seduh dengan 60 ml air panas hingga larut, kemudian tambahkan sekitar 90 gram es batu.','Sachet','/produk/PRD_20037601647.jpg','',NULL,'0','0','2025-12-28 16:53:23');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_20669949571','78','Top White Coffee','2500.00','Top White Coffee adalah varian kopi instan siap seduh dari Wings Corp yang memadukan kelembutan krimer nabati dengan karakter rasa kopi yang kuat dan harum. Produk ini dirancang khusus untuk para pencinta kopi yang menginginkan sensasi white coffee premium dengan harga ekonomis dan kemasan yang praktis.Berikut adalah rincian deskripsi produk untuk kebutuhan penjualan, katalog, atau promosi Anda:🌟 Keunggulan ProdukPerpaduan Biji Kopi Premium: Mengombinasikan biji kopi Robusta dan Arabika pilihan untuk menciptakan rasa yang seimbang, aroma harum, dan karakter yang kompleks.Tekstur Lembut & Creamy: Menggunakan krimer berkualitas tinggi yang menghasilkan konsistensi lembut di mulut tanpa menutupi rasa asli kopinya.Ramah di Lambung: Ciri khas proses white coffee yang menggunakan suhu pemanggangan lebih rendah membuat tingkat keasamannya cenderung lebih ramah bagi lambung.Praktis & Ekonomis: Dikemas dalam bentuk sachet siap seduh yang sudah mencakup kopi, gula, dan krimer.\r\n\r\n\r\nznfsif','Sachet','/produk/PRD_20669949571.png','',NULL,'0','0','2025-12-28 16:54:27');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_20715061932','78','Aqua 330 ML','3000.00','','Botol','/produk/PRD_20715061932.jpg','',NULL,'0','0','2025-12-28 14:07:51');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_21948382265','78','Teh Pucuk 350 ML','5000.00','','Botol','/produk/PRD_21948382265.jpg','',NULL,'0','0','2025-12-28 14:09:54');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_23259949343','78','Teh Kotak 300 ML','5000.00','','Pcs','/produk/PRD_23259949343.png','',NULL,'0','0','2025-12-28 14:12:05');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_23765443715','78','Sari Kacang Hijau 250 ML','6000.00','','Pcs','/produk/PRD_23765443715.jpg','',NULL,'0','0','2025-12-28 14:12:56');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_24254357879','78','You C 1000 ORANGE','10000.00','','Botol','/produk/PRD_24254357879.webp','',NULL,'0','0','2025-12-28 14:13:45');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_25312761177','78','Fanta 330 ML','7000.00','','Kaleng','/produk/PRD_25312761177.jpg','',NULL,'0','0','2025-12-28 14:15:31');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_25863427374','78','Sprite 330 ML','7000.00','','Kaleng','/produk/PRD_25863427374.jpg','',NULL,'0','0','2025-12-28 14:16:26');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_27131014176','78','Pocari Sweat 350 ML','7500.00','','Botol','/produk/PRD_27131014176.webp','',NULL,'0','0','2025-12-28 14:18:33');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_27464033182','78','Pocari Sweat 500 ML','8500.00','','Botol','/produk/PRD_27464033182.webp','',NULL,'0','0','2025-12-28 14:19:06');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_34331235266','77','Kunyit Instan','20000.00','Kunyit Instan dari Jemaat Fatubena adalah bubuk kunyit siap seduh alami yang diolah secara higienis tanpa bahan pengawet kimia. Produk ini merupakan hasil produksi lokal yang tidak hanya menawarkan kepraktisan untuk kesehatan dan bumbu dapur, tetapi juga mendukung perekonomian komunitas usaha mikro di daerah Fatubena.Berikut adalah draf deskripsi produk yang dioptimalkan untuk halaman penjualan toko online Anda:🌟 Keunggulan ProdukAlami & Higienis: Terbuat dari rimpang kunyit pilihan yang diproses bersih tanpa campuran zat kimia berbahaya.Multifungsi: Dapat diseduh langsung sebagai minuman herbal (jamu) hangat penambah daya tahan tubuh, maupun digunakan sebagai bumbu praktis untuk masakan dapur.Mendukung Produk Lokal: Setiap pembelian produk ini berkontribusi langsung pada pemberdayaan ekonomi Jemaat Fatubena.📝 Spesifikasi ProdukNama Produk: Kunyit Instan Jemaat FatubenaKode Produk: PRD_34331235266Kategori: Minyak & Bumbu DapurHarga: Rp 20.000Status Stok: 1 unit tersedia (Sangat Terbatas)Asal / Produsen: Jemaat Fatubena☕ Cara PenggunaanUntuk Minuman Kesehatan: Ambil 1-2 sendok teh bubuk kunyit instan, seduh dengan segelas air hangat. Bisa ditambahkan madu atau lemon sesuai selera.Untuk Bumbu Masak: Masukkan secukupnya ke dalam masakan seperti soto, gulai, ayam ungkep, atau hidangan lainnya sesuai takaran resep.','PCS','/produk/PRD_34331235266.png','Jemaat Fatubena','Kunyit Instan siap seduh dan alami. tanpa bahan kimia.','0','0','2025-12-19 11:03:55');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_40477704712','78','Kopi Meto','55000.00','','Pcs','/produk/PRD_40477704712.png','Kelompok Kofi Metode Bitobe(Sonan, Bioba)','Aroma khas Bitobe, rasa kuat alami tiap cangkir.','0','0','2025-12-19 11:14:09');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_55071163152','77','Gula Semut','10000.00','','Pcs','/produk/PRD_55071163152.png','Imanuel Rote Barat Laut','Manis alami gula semut Imanuel, rasa otentik Rote.','0','0','2025-12-19 14:25:09');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_56095135699','77','Garam Yodium Oebelo Tanah Merah','15000.00','','Bakun','/produk/PRD_56095135699.png','Klasis Kupang Tengah','Garam Yodium Oebelo, rasa alami dari Tanah Merah Kupang.','0','0','2025-12-19 14:26:51');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_58480927407','76','Tepung Mokaf Original','15000.00','','Pcs','/produk/PRD_58480927407.png','Jemaat Sopo, Klasis Amanuban Tengah Uatar','Tepung Mokaf asli Sopo, tekstur halus, rasa otentik.','0','0','2025-12-19 14:30:50');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_60274096744','78','Kopi Amfoang','60000.00','','Pcs','/produk/PRD_60274096744.png','Istana Hijau Lelogama','Kopi Amfoang dari Istana Hijau, rasa alami yang memikat.','0','0','2025-12-19 14:33:49');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_61762411140','77','Kecap Manis Sedap','1.00','','Pcs','/produk/PRD_61762411140.png','',NULL,'0','0','2025-12-19 14:36:18');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_65671504693','79','Gula Lempeng Tuamese 1KG','30000.00','','Pcs','/produk/PRD_65671504693.png','-','Gula lempeng Tuamese, manis pas, serbaguna untuk masak.','0','0','2025-12-19 14:42:49');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_66878007736','79','Gula Lempeng Rote','10000.00','','Pcs','/produk/PRD_66878007736.png','Imanuel Ndau / RBL','Manis alami Gula Lempeng Rote, rasa khas pulau sejuk.','0','0','2025-12-19 14:44:49');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_70956539291','79','Nu Koennu Minyak Herbal','50000.00','...','Botol','/produk/PRD_70956539291.png','Napago Farm Kupang, NTT','Minyak herbal Napago Farm, alami, menenangkan tubuh secara lembut.','0','0','2025-12-19 14:51:37');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_90212598279','78','Aqua 600 ML','5000.00','','Botol','/produk/PRD_90212598279.webp','',NULL,'0','0','2025-12-28 14:08:45');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_96761227467','80','Cokelat KELOR-S','15000.00','','Pcs','/produk/PRD_96761227467.png','Niki Niki Amanuban Tengah, TTS','Rasa alami khas Niki niki Amanuban Tengah.','0','0','2025-12-19 12:47:58');
INSERT INTO `produk` (`kode_produk`,`id_kategori`,`nama_produk`,`harga_jual`,`deskripsi`,`satuan_dasar`,`gambar`,`asal_produk`,`tagline`,`stok`,`terjual`,`tanggal_dibuat`) VALUES ('PRD_97964235986','80','Kacang Telur','12500.00','','Pcs','/produk/PRD_97964235986.png','HomeMade Moms, Penfui Kupang NTT','Kacang telur Homemade Moms, gurih alami rasa tradisional Kupang.','0','0','2025-12-19 12:49:58');
DROP TABLE IF EXISTS `reservasi_stok`;
CREATE TABLE `reservasi_stok` (
  `kode_transaksi` varchar(15) NOT NULL,
  `kode_produk` varchar(15) NOT NULL,
  `jumlah` int(11) NOT NULL,
  PRIMARY KEY (`kode_transaksi`,`kode_produk`),
  KEY `kode_produk` (`kode_produk`),
  CONSTRAINT `reservasi_stok_ibfk_1` FOREIGN KEY (`kode_transaksi`) REFERENCES `transaksi` (`kode_transaksi`) ON DELETE CASCADE,
  CONSTRAINT `reservasi_stok_ibfk_2` FOREIGN KEY (`kode_produk`) REFERENCES `produk` (`kode_produk`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `riwayat_pembayaran`;
CREATE TABLE `riwayat_pembayaran` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kode_transaksi` varchar(15) NOT NULL,
  `status` varchar(30) NOT NULL,
  `catatan` varchar(500) DEFAULT NULL,
  `petugas` int(11) DEFAULT NULL,
  `tanggal` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `kode_transaksi` (`kode_transaksi`),
  CONSTRAINT `riwayat_pembayaran_ibfk_1` FOREIGN KEY (`kode_transaksi`) REFERENCES `transaksi` (`kode_transaksi`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('2','GG-0423BF783EA9','lunas','Pembayaran diterima.',NULL,'2026-10-12 09:15:00');
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('3','GG-F66DE86C0F47','lunas','Pembayaran diterima.',NULL,'2026-10-11 10:15:00');
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('4','GG-64AC5C9D9F7B','lunas','Pembayaran diterima.',NULL,'2026-10-10 11:15:00');
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('5','GG-9542E5026F3B','lunas','Pembayaran diterima.',NULL,'2026-10-09 12:15:00');
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('6','GG-08F3C54E61D1','lunas','Pembayaran diterima.',NULL,'2026-10-07 13:15:00');
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('7','GG-A985CD63D2A0','lunas','Pembayaran diterima.',NULL,'2026-09-30 14:15:00');
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('8','GG-28318AA3CF53','lunas','Pembayaran diterima.',NULL,'2026-09-09 15:15:00');
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('9','GG-7CDDC6D37F3E','belum_bayar','Menunggu pembayaran.',NULL,'2026-10-12 09:15:00');
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('10','GG-757FE875C94F','lunas','Pembayaran diterima.',NULL,'2026-10-12 10:15:00');
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('11','GG-73D4D10DCAA1','belum_bayar','Menunggu pembayaran.',NULL,'2026-10-10 11:15:00');
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('12','GG-73D4D10DCAA1','belum_bayar','Pesanan dibatalkan.',NULL,'2026-10-12 18:49:34');
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('27','GG-9D68EBB6D777','belum_bayar','Pesanan dibuat.',NULL,'2026-10-12 18:58:14');
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('31','GG-7CDDC6D37F3E','belum_bayar','Pesanan dibatalkan.','22','2026-10-12 19:09:16');
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('41','GG-BC4714506D05','belum_bayar','Pesanan dibuat.',NULL,'2026-10-12 19:38:30');
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('42','GG-88BDD71C994D','belum_bayar','Pesanan dibuat.',NULL,'2026-10-12 19:40:09');
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('43','GG-88BDD71C994D','lunas','Pembayaran QRIS dikonfirmasi Midtrans.',NULL,'2026-10-12 19:41:42');
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('44','GG-BC4714506D05','kedaluwarsa','Pembayaran QRIS berakhir: cancel',NULL,'2026-10-12 19:44:30');
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('45','GG-9D68EBB6D777','kedaluwarsa','Pembayaran QRIS berakhir: cancel',NULL,'2026-10-12 19:44:38');
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('46','GG-5000AB552B3B','belum_bayar','Pesanan dibuat.',NULL,'2026-10-12 19:44:43');
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('47','GG-5000AB552B3B','lunas','Pembayaran tunai diterima.','1','2026-10-12 19:44:43');
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('48','GG-3B6DBC7919F6','belum_bayar','Pesanan dibuat.',NULL,'2026-10-12 19:45:00');
INSERT INTO `riwayat_pembayaran` (`id`,`kode_transaksi`,`status`,`catatan`,`petugas`,`tanggal`) VALUES ('49','GG-3B6DBC7919F6','lunas','Pembayaran QRIS dikonfirmasi Midtrans.',NULL,'2026-10-12 19:45:20');
DROP TABLE IF EXISTS `transaksi`;
CREATE TABLE `transaksi` (
  `kode_transaksi` varchar(15) NOT NULL,
  `id_pengguna` int(11) DEFAULT NULL,
  `tanggal_transaksi` datetime DEFAULT current_timestamp(),
  `total_harga` decimal(12,2) NOT NULL,
  `total_pokok` decimal(12,2) DEFAULT NULL,
  `status` enum('pending','diproses','dibatalkan','selesai') DEFAULT 'pending',
  `metode_bayar` enum('tunai','transfer','qris') DEFAULT 'tunai',
  `status_bayar` varchar(30) NOT NULL DEFAULT 'belum_bayar',
  `metode_pengiriman` varchar(10) NOT NULL DEFAULT 'ambil',
  `kelurahan` varchar(100) DEFAULT NULL,
  `nama_penerima` varchar(150) DEFAULT NULL,
  `no_hp_penerima` varchar(25) DEFAULT NULL,
  `alamat_pengiriman` text DEFAULT NULL,
  `ongkir` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_tagihan` decimal(12,2) NOT NULL DEFAULT 0.00,
  `batas_bayar` datetime DEFAULT NULL,
  `tanggal_bayar` datetime DEFAULT NULL,
  `tanggal_selesai` datetime DEFAULT NULL,
  `bukti_bayar` varchar(255) DEFAULT NULL,
  `catatan_bayar` varchar(500) DEFAULT NULL,
  `midtrans_order_id` varchar(80) DEFAULT NULL,
  `midtrans_id` varchar(100) DEFAULT NULL,
  `midtrans_env` varchar(15) DEFAULT NULL,
  `qris_url` varchar(500) DEFAULT NULL,
  `checkout_key` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`kode_transaksi`),
  UNIQUE KEY `uq_checkout_key` (`checkout_key`),
  UNIQUE KEY `uq_midtrans_order` (`midtrans_order_id`),
  KEY `idx_kode_transaksi` (`kode_transaksi`),
  KEY `idx_tanggal_transaksi` (`tanggal_transaksi`),
  KEY `idx_metode_bayar` (`metode_bayar`),
  KEY `idx_id_user` (`id_pengguna`),
  CONSTRAINT `fk_transaksi_user` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id_pengguna`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `transaksi` (`kode_transaksi`,`id_pengguna`,`tanggal_transaksi`,`total_harga`,`total_pokok`,`status`,`metode_bayar`,`status_bayar`,`metode_pengiriman`,`kelurahan`,`nama_penerima`,`no_hp_penerima`,`alamat_pengiriman`,`ongkir`,`total_tagihan`,`batas_bayar`,`tanggal_bayar`,`tanggal_selesai`,`bukti_bayar`,`catatan_bayar`,`midtrans_order_id`,`midtrans_id`,`midtrans_env`,`qris_url`,`checkout_key`) VALUES ('GG-0423BF783EA9','22','2026-10-12 09:15:00','65000.00','45500.00','selesai','tunai','lunas','ambil',NULL,'pelanggan','085829230787',NULL,'0.00','65000.00','2026-10-12 20:49:34','2026-10-12 09:15:00','2026-10-12 09:15:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `transaksi` (`kode_transaksi`,`id_pengguna`,`tanggal_transaksi`,`total_harga`,`total_pokok`,`status`,`metode_bayar`,`status_bayar`,`metode_pengiriman`,`kelurahan`,`nama_penerima`,`no_hp_penerima`,`alamat_pengiriman`,`ongkir`,`total_tagihan`,`batas_bayar`,`tanggal_bayar`,`tanggal_selesai`,`bukti_bayar`,`catatan_bayar`,`midtrans_order_id`,`midtrans_id`,`midtrans_env`,`qris_url`,`checkout_key`) VALUES ('GG-08F3C54E61D1','22','2026-10-07 13:15:00','90000.00','63000.00','selesai','transfer','lunas','ambil',NULL,'pelanggan','085829230787',NULL,'0.00','90000.00','2026-10-12 20:49:34','2026-10-07 13:15:00','2026-10-07 13:15:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `transaksi` (`kode_transaksi`,`id_pengguna`,`tanggal_transaksi`,`total_harga`,`total_pokok`,`status`,`metode_bayar`,`status_bayar`,`metode_pengiriman`,`kelurahan`,`nama_penerima`,`no_hp_penerima`,`alamat_pengiriman`,`ongkir`,`total_tagihan`,`batas_bayar`,`tanggal_bayar`,`tanggal_selesai`,`bukti_bayar`,`catatan_bayar`,`midtrans_order_id`,`midtrans_id`,`midtrans_env`,`qris_url`,`checkout_key`) VALUES ('GG-28318AA3CF53','22','2026-09-09 15:15:00','65000.00','45500.00','selesai','tunai','lunas','ambil',NULL,'pelanggan','085829230787',NULL,'0.00','65000.00','2026-10-12 20:49:34','2026-09-09 15:15:00','2026-09-09 15:15:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `transaksi` (`kode_transaksi`,`id_pengguna`,`tanggal_transaksi`,`total_harga`,`total_pokok`,`status`,`metode_bayar`,`status_bayar`,`metode_pengiriman`,`kelurahan`,`nama_penerima`,`no_hp_penerima`,`alamat_pengiriman`,`ongkir`,`total_tagihan`,`batas_bayar`,`tanggal_bayar`,`tanggal_selesai`,`bukti_bayar`,`catatan_bayar`,`midtrans_order_id`,`midtrans_id`,`midtrans_env`,`qris_url`,`checkout_key`) VALUES ('GG-3B6DBC7919F6','1','2026-10-12 19:45:00','45000.00','31500.00','selesai','qris','lunas','ambil',NULL,'admin',NULL,NULL,'0.00','45000.00','2026-10-12 21:45:00','2026-10-12 19:45:20','2026-10-12 19:45:22',NULL,NULL,'GG-3B6DBC7919F6','67599c3f-3a13-407a-8179-218ad2c6707b','sandbox','https://merchants-app.sbx.midtrans.com/v4/qris/gopay/A120261012114507e6LxXQON8FID/qr-code','7e38aeea-25e2-4847-93b4-1a9c684df6c9');
INSERT INTO `transaksi` (`kode_transaksi`,`id_pengguna`,`tanggal_transaksi`,`total_harga`,`total_pokok`,`status`,`metode_bayar`,`status_bayar`,`metode_pengiriman`,`kelurahan`,`nama_penerima`,`no_hp_penerima`,`alamat_pengiriman`,`ongkir`,`total_tagihan`,`batas_bayar`,`tanggal_bayar`,`tanggal_selesai`,`bukti_bayar`,`catatan_bayar`,`midtrans_order_id`,`midtrans_id`,`midtrans_env`,`qris_url`,`checkout_key`) VALUES ('GG-5000AB552B3B','1','2026-10-12 19:44:43','90000.00','63000.00','selesai','tunai','lunas','ambil',NULL,'admin',NULL,NULL,'0.00','90000.00','2026-10-12 21:44:43','2026-10-12 19:44:43','2026-10-12 19:44:43',NULL,NULL,NULL,NULL,NULL,NULL,'d65c6c59-f179-4c18-b4c2-e53b4e0024a9');
INSERT INTO `transaksi` (`kode_transaksi`,`id_pengguna`,`tanggal_transaksi`,`total_harga`,`total_pokok`,`status`,`metode_bayar`,`status_bayar`,`metode_pengiriman`,`kelurahan`,`nama_penerima`,`no_hp_penerima`,`alamat_pengiriman`,`ongkir`,`total_tagihan`,`batas_bayar`,`tanggal_bayar`,`tanggal_selesai`,`bukti_bayar`,`catatan_bayar`,`midtrans_order_id`,`midtrans_id`,`midtrans_env`,`qris_url`,`checkout_key`) VALUES ('GG-64AC5C9D9F7B','22','2026-10-10 11:15:00','135000.00','94500.00','selesai','qris','lunas','ambil',NULL,'pelanggan','085829230787',NULL,'0.00','135000.00','2026-10-12 20:49:34','2026-10-10 11:15:00','2026-10-10 11:15:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `transaksi` (`kode_transaksi`,`id_pengguna`,`tanggal_transaksi`,`total_harga`,`total_pokok`,`status`,`metode_bayar`,`status_bayar`,`metode_pengiriman`,`kelurahan`,`nama_penerima`,`no_hp_penerima`,`alamat_pengiriman`,`ongkir`,`total_tagihan`,`batas_bayar`,`tanggal_bayar`,`tanggal_selesai`,`bukti_bayar`,`catatan_bayar`,`midtrans_order_id`,`midtrans_id`,`midtrans_env`,`qris_url`,`checkout_key`) VALUES ('GG-73D4D10DCAA1','22','2026-10-10 11:15:00','65000.00','0.00','dibatalkan','tunai','belum_bayar','kirim','Fatululi','pelanggan','085829230787','Jl Perintis Kemerdekaan 1','5000.00','70000.00','2026-10-12 20:49:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `transaksi` (`kode_transaksi`,`id_pengguna`,`tanggal_transaksi`,`total_harga`,`total_pokok`,`status`,`metode_bayar`,`status_bayar`,`metode_pengiriman`,`kelurahan`,`nama_penerima`,`no_hp_penerima`,`alamat_pengiriman`,`ongkir`,`total_tagihan`,`batas_bayar`,`tanggal_bayar`,`tanggal_selesai`,`bukti_bayar`,`catatan_bayar`,`midtrans_order_id`,`midtrans_id`,`midtrans_env`,`qris_url`,`checkout_key`) VALUES ('GG-757FE875C94F','22','2026-10-12 10:15:00','135000.00','94500.00','selesai','transfer','lunas','ambil',NULL,'pelanggan','085829230787',NULL,'0.00','135000.00','2026-10-12 20:49:34','2026-10-12 10:15:00','2026-10-12 19:06:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `transaksi` (`kode_transaksi`,`id_pengguna`,`tanggal_transaksi`,`total_harga`,`total_pokok`,`status`,`metode_bayar`,`status_bayar`,`metode_pengiriman`,`kelurahan`,`nama_penerima`,`no_hp_penerima`,`alamat_pengiriman`,`ongkir`,`total_tagihan`,`batas_bayar`,`tanggal_bayar`,`tanggal_selesai`,`bukti_bayar`,`catatan_bayar`,`midtrans_order_id`,`midtrans_id`,`midtrans_env`,`qris_url`,`checkout_key`) VALUES ('GG-7CDDC6D37F3E','22','2026-10-12 09:15:00','90000.00','0.00','dibatalkan','transfer','belum_bayar','kirim','Fatululi','pelanggan','085829230787','Jl Perintis Kemerdekaan 1','5000.00','95000.00','2026-10-12 20:49:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `transaksi` (`kode_transaksi`,`id_pengguna`,`tanggal_transaksi`,`total_harga`,`total_pokok`,`status`,`metode_bayar`,`status_bayar`,`metode_pengiriman`,`kelurahan`,`nama_penerima`,`no_hp_penerima`,`alamat_pengiriman`,`ongkir`,`total_tagihan`,`batas_bayar`,`tanggal_bayar`,`tanggal_selesai`,`bukti_bayar`,`catatan_bayar`,`midtrans_order_id`,`midtrans_id`,`midtrans_env`,`qris_url`,`checkout_key`) VALUES ('GG-88BDD71C994D','1','2026-10-12 19:40:09','45000.00','31500.00','selesai','qris','lunas','ambil',NULL,'admin',NULL,NULL,'0.00','45000.00','2026-10-12 21:40:09','2026-10-12 19:41:42','2026-10-12 19:41:55',NULL,NULL,'GG-88BDD71C994D','f196f664-b380-40d2-a39c-36da41d148c7','sandbox','https://merchants-app.sbx.midtrans.com/v4/qris/gopay/A120261012114026oHVs6EPYX7ID/qr-code','a73d6bc1-c666-4a8a-a71f-b617dc5607e7');
INSERT INTO `transaksi` (`kode_transaksi`,`id_pengguna`,`tanggal_transaksi`,`total_harga`,`total_pokok`,`status`,`metode_bayar`,`status_bayar`,`metode_pengiriman`,`kelurahan`,`nama_penerima`,`no_hp_penerima`,`alamat_pengiriman`,`ongkir`,`total_tagihan`,`batas_bayar`,`tanggal_bayar`,`tanggal_selesai`,`bukti_bayar`,`catatan_bayar`,`midtrans_order_id`,`midtrans_id`,`midtrans_env`,`qris_url`,`checkout_key`) VALUES ('GG-9542E5026F3B','22','2026-10-09 12:15:00','65000.00','45500.00','selesai','tunai','lunas','kirim','Fatululi','pelanggan','085829230787','Jl Perintis Kemerdekaan 1','5000.00','70000.00','2026-10-12 20:49:34','2026-10-09 12:15:00','2026-10-09 12:15:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `transaksi` (`kode_transaksi`,`id_pengguna`,`tanggal_transaksi`,`total_harga`,`total_pokok`,`status`,`metode_bayar`,`status_bayar`,`metode_pengiriman`,`kelurahan`,`nama_penerima`,`no_hp_penerima`,`alamat_pengiriman`,`ongkir`,`total_tagihan`,`batas_bayar`,`tanggal_bayar`,`tanggal_selesai`,`bukti_bayar`,`catatan_bayar`,`midtrans_order_id`,`midtrans_id`,`midtrans_env`,`qris_url`,`checkout_key`) VALUES ('GG-9D68EBB6D777','1','2026-10-12 18:58:14','110000.00','0.00','dibatalkan','qris','kedaluwarsa','ambil',NULL,'admin',NULL,NULL,'0.00','110000.00','2026-10-12 20:58:14',NULL,NULL,NULL,NULL,'GG-9D68EBB6D777','4e617ecf-d22e-4634-88b6-2a63a98e81d3','sandbox','https://api.sandbox.midtrans.com/v2/qris/4e617ecf-d22e-4634-88b6-2a63a98e81d3/qr-code','81249061-7446-47fb-9591-76bae545034a');
INSERT INTO `transaksi` (`kode_transaksi`,`id_pengguna`,`tanggal_transaksi`,`total_harga`,`total_pokok`,`status`,`metode_bayar`,`status_bayar`,`metode_pengiriman`,`kelurahan`,`nama_penerima`,`no_hp_penerima`,`alamat_pengiriman`,`ongkir`,`total_tagihan`,`batas_bayar`,`tanggal_bayar`,`tanggal_selesai`,`bukti_bayar`,`catatan_bayar`,`midtrans_order_id`,`midtrans_id`,`midtrans_env`,`qris_url`,`checkout_key`) VALUES ('GG-A985CD63D2A0','22','2026-09-30 14:15:00','135000.00','94500.00','selesai','qris','lunas','kirim','Fatululi','pelanggan','085829230787','Jl Perintis Kemerdekaan 1','5000.00','140000.00','2026-10-12 20:49:34','2026-09-30 14:15:00','2026-09-30 14:15:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `transaksi` (`kode_transaksi`,`id_pengguna`,`tanggal_transaksi`,`total_harga`,`total_pokok`,`status`,`metode_bayar`,`status_bayar`,`metode_pengiriman`,`kelurahan`,`nama_penerima`,`no_hp_penerima`,`alamat_pengiriman`,`ongkir`,`total_tagihan`,`batas_bayar`,`tanggal_bayar`,`tanggal_selesai`,`bukti_bayar`,`catatan_bayar`,`midtrans_order_id`,`midtrans_id`,`midtrans_env`,`qris_url`,`checkout_key`) VALUES ('GG-BC4714506D05','22','2026-10-12 19:38:30','45000.00','0.00','dibatalkan','qris','kedaluwarsa','kirim','Bonipoi','pelanggan','6285829230787','Jl Perintis Kemerdekaan 1','15000.00','60000.00','2026-10-12 21:38:30',NULL,NULL,NULL,NULL,'GG-BC4714506D05','c56f060d-f6e3-4f93-ae46-e9b2a774365f','sandbox','https://merchants-app.sbx.midtrans.com/v4/qris/gopay/A120261012113839tTsKXiiHjBID/qr-code','cb28b84f-d8a1-45f5-9b7f-a4339aeb3bb4');
INSERT INTO `transaksi` (`kode_transaksi`,`id_pengguna`,`tanggal_transaksi`,`total_harga`,`total_pokok`,`status`,`metode_bayar`,`status_bayar`,`metode_pengiriman`,`kelurahan`,`nama_penerima`,`no_hp_penerima`,`alamat_pengiriman`,`ongkir`,`total_tagihan`,`batas_bayar`,`tanggal_bayar`,`tanggal_selesai`,`bukti_bayar`,`catatan_bayar`,`midtrans_order_id`,`midtrans_id`,`midtrans_env`,`qris_url`,`checkout_key`) VALUES ('GG-F66DE86C0F47','22','2026-10-11 10:15:00','90000.00','63000.00','selesai','transfer','lunas','kirim','Fatululi','pelanggan','085829230787','Jl Perintis Kemerdekaan 1','5000.00','95000.00','2026-10-12 20:49:34','2026-10-11 10:15:00','2026-10-11 10:15:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
DROP TABLE IF EXISTS `zona_pengiriman`;
CREATE TABLE `zona_pengiriman` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kelurahan` varchar(100) NOT NULL,
  `tarif` decimal(12,2) NOT NULL,
  `aktif` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kelurahan` (`kelurahan`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('1','Kelapa Lima','5000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('2','Pasir Panjang','5000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('3','Fatululi','5000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('4','Nefonaek','5000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('5','Oebobo','10000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('6','Oetete','10000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('7','Kayu Putih','10000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('8','Fatubesi','10000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('9','Oeba','10000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('10','Oesapa Barat','10000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('11','Oesapa Selatan','10000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('12','Tuak Daun Merah','15000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('13','Oebufu','15000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('14','Oesapa','15000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('15','Bonipoi','15000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('16','Solor','15000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('17','Tode Kisar','15000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('18','Merdeka','15000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('19','Lai Lai Bisi Kopan','15000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('20','Fontein','15000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('21','Nunleu','15000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('22','Kuanino','15000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('23','Airnona','15000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('24','Naikoten Satu','15000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('25','Naikoten Dua','15000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('26','Oepura','15000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('27','Naikolan','15000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('28','Bakunase','15000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('29','Nunhila','15000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('30','Fatufeto','15000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('31','Nunbaun Sabu','15000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('32','Airmata','15000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('33','Liliba','20000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('34','Naimata','20000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('35','Maulafa','20000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('36','Sikumana','20000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('37','Bello','20000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('38','Kolhua','20000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('39','Bakunase Dua','20000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('40','Nunbaun Delha','20000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('41','Manutapen','20000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('42','Mantasi','20000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('43','Namosain','20000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('44','Lasiana','25000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('45','Penfui','25000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('46','Batu Plat','25000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('47','Penkase Oeleta','25000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('48','Alak','30000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('49','Manulai II','30000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('50','Fatukoa','30000.00','1');
INSERT INTO `zona_pengiriman` (`id`,`kelurahan`,`tarif`,`aktif`) VALUES ('51','Naioni','35000.00','1');
SET FOREIGN_KEY_CHECKS=1;

<div class="user-container space-y-5 py-8">
  <div><h1 class="user-section-title"><?= ($_SESSION['user']['role'] ?? '') === 'pelanggan' ? 'Pembayaran Pesanan' : 'Pembayaran' ?></h1><p class="user-section-subtitle"><?= ($_SESSION['user']['role'] ?? '') === 'pelanggan' ? 'Selesaikan pembayaran dan pantau pesanan.' : 'Selesaikan pembayaran. Setelah lunas, struk dicetak bila dipilih dan halaman kembali ke kasir.' ?></p></div>
  <?php include ROOT_PATH . '/app/views/partials/payment.php'; ?>
  <a href="<?= BASE_URL . (($_SESSION['user']['role'] ?? '') === 'pelanggan' ? '/transaksi' : '/admin/kasir') ?>" class="user-action-outline"><?= ($_SESSION['user']['role'] ?? '') === 'pelanggan' ? 'Pesanan Saya' : 'Layani pembeli berikutnya' ?></a>
</div>
